"""UEM action executor.

Two adapters:
  - SimulationAdapter: records the action locally (no real device contact).
    Perfect for a 100%-local, fully-functional demo.
  - LiveAdapter: performs a real HTTP call to the Applivery UEM (MDM) API using
    the service-account token in APPLIVERY_API_KEY. If the command endpoint is
    unavailable (Applivery's public REST API does NOT expose remote commands such
    as lock/wipe - our probes returned 404 for every candidate path), the adapter
    delegates the remediation via a configurable webhook (enterprise pattern:
    Zapier/Make/PowerAutomate) and records the delegation. It never raises, so
    the dashboard never 500s.

Verified contract (2026-07-09, live against api.applivery.io with a real token):
  Auth : Authorization: Bearer <APPLIVERY_API_KEY>   (NOT X-Api-Token)
  Base : https://api.applivery.io/v1
  Devices list: GET /v1/organizations/{org}/mdm/devices   (200; returns data.items)
  Command endpoint: POST /v1/organizations/{org}/mdm/devices/{deviceId}/commands
    NOTE: the remote-command endpoint is not part of the public API reference and
    our probes returned 404 for every candidate path. The adapter uses the
    standard UEM path and - on failure - falls back to the remediation webhook.

Both adapters return a normalized result dict that the engine logs.
"""
from __future__ import annotations

import json
import os
import time
import uuid
from typing import Any, Optional

import requests

VALID_ACTIONS = {
    "lock",
    "wipe",
    "message",
    "locate",
    "reboot",
    "clear_passcode",
    "custom",
}


class SimulationAdapter:
    name = "simulation"

    def execute(self, device: Any, action: str, params: dict, dry_run: bool = False) -> dict:
        cmd_id = f"sim-{uuid.uuid4().hex[:12]}"
        return {
            "adapter": self.name,
            "ok": True,
            "command_id": cmd_id,
            "device_id": getattr(device, "device_id", None),
            "device_name": getattr(device, "name", None),
            "action": action,
            "params": params,
            "dry_run": dry_run,
            "note": "Simulated action (no real device contacted).",
        }


class LiveAdapter:
    name = "live"

    def __init__(self, org_id: str, endpoint_template: str, timeout: int = 30,
                 webhook_url: str = "", api_key: str = ""):
        self.org_id = org_id
        self.api_key = api_key or ""
        # Standard Applivery UEM command path (see module docstring re: 404 probes).
        self.endpoint_template = endpoint_template or "/organizations/{org_id}/mdm/devices/{device_id}/commands"
        self.timeout = timeout
        # Enterprise remediation webhook (Zapier/Make/PowerAutomate). When the
        # Applivery command endpoint is unavailable, the action is delegated here.
        self.webhook_url = webhook_url or os.environ.get("REMEDIATION_WEBHOOK_URL", "")

    def _headers(self) -> dict:
        key = self.api_key or os.environ.get("APPLIVERY_API_KEY") or os.environ.get("applivery_api_key")
        if not key:
            raise RuntimeError("APPLIVERY_API_KEY not set; cannot run live UEM actions.")
        # Applivery Organizations (UEM) API authenticates with a service-account
        # Bearer token (official Applivery MCP applivery_learn contract).
        return {
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _delegate_webhook(self, device: Any, action: str, params: dict, reason: str) -> dict:
        device_id = getattr(device, "device_id", None)
        payload = {
            "event": "geofence_remediation",
            "device_id": device_id,
            "device_name": getattr(device, "name", None),
            "platform": getattr(device, "platform", None),
            "action": action,
            "params": params or {},
            "org_id": self.org_id,
            "reason": reason,
            "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        if not self.webhook_url:
            return {
                "delegated": False,
                "webhook": None,
                "note": "No remediation webhook configured; action not delegated.",
            }
        try:
            r = requests.post(
                self.webhook_url,
                headers={"Content-Type": "application/json"},
                data=json.dumps(payload),
                timeout=self.timeout,
            )
            accepted = 200 <= r.status_code < 300
            return {
                "delegated": accepted,
                "attempted": True,
                "webhook": self.webhook_url,
                "webhook_status": r.status_code,
                "webhook_response": _safe_text(r),
                "payload": payload,
                **({} if accepted else {"error": f"webhook returned HTTP {r.status_code}"}),
            }

        except Exception as exc:
            return {
                "delegated": False,
                "webhook": self.webhook_url,
                "error": f"webhook failed: {type(exc).__name__}: {exc}",
            }

    def execute(self, device: Any, action: str, params: dict, dry_run: bool = False) -> dict:
        key = self.api_key or os.environ.get("APPLIVERY_API_KEY") or os.environ.get("applivery_api_key")
        device_id = getattr(device, "device_id", None)
        if not key:
            return {
                "adapter": self.name,
                "ok": False,
                "device_id": device_id,
                "action": action,
                "error": "APPLIVERY_API_KEY not set",
            }
        path = self.endpoint_template.format(org_id=self.org_id, device_id=device_id)
        base = os.environ.get("APPLIVERY_API_BASE", "https://api.applivery.io/v1").rstrip("/")
        url = f"{base}{path}"
        # Applivery command body: {"command": "lock|wipe|message|locate|reboot|clear_passcode", "params": {...}}
        body = {"command": action, "params": params or {}}
        if dry_run:
            return {
                "adapter": self.name,
                "ok": True,
                "dry_run": True,
                "device_id": device_id,
                "action": action,
                "method": "POST",
                "url": url,
                "body": body,
                "note": "Dry run: request built but not sent.",
            }
        # --- 1) attempt the native UEM command ---
        http_result = None
        try:
            r = requests.post(url, headers=self._headers(), json=body, timeout=self.timeout)
            http_result = {
                "status_code": r.status_code,
                "ok": r.ok,
                "response": _safe_text(r),
            }
        except Exception as exc:
            http_result = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}

        # --- 2) native command succeeded -> done ---
        if http_result.get("ok"):
            return {
                "adapter": self.name,
                "ok": True,
                "device_id": device_id,
                "action": action,
                "method": "POST",
                "url": url,
                "status_code": http_result.get("status_code"),
                "response": http_result.get("response"),
            }

        # --- 3) native command unavailable -> delegate via remediation webhook ---
        reason = (
            f"Applivery command endpoint unavailable "
            f"(HTTP {http_result.get('status_code') or http_result.get('error')})"
        )
        delegation = self._delegate_webhook(device, action, params, reason)
        return {
            "adapter": self.name,
            "ok": False,
            "delegated": delegation.get("delegated", False),
            "device_id": device_id,
            "action": action,
            "method": "POST",
            "url": url,
            "http_result": http_result,
            "delegation": delegation,
            "note": "Native command failed; remediation delegated via webhook."
            if delegation.get("delegated")
            else "Native command failed; no remediation webhook configured.",
        }


def _safe_text(r: requests.Response) -> str:
    try:
        return r.text[:500]
    except Exception:
        return ""


def build_adapter(mode: str, org_id: str, endpoint_template: str,
                  webhook_url: str = "", api_key: str = "") -> Any:
    if mode == "live":
        return LiveAdapter(org_id=org_id, endpoint_template=endpoint_template,
                           webhook_url=webhook_url, api_key=api_key)
    return SimulationAdapter()
