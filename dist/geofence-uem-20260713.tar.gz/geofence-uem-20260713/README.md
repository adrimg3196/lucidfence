# Geofence UEM — producto local de geofencing sobre Applivery

Producto 100% funcional en local (macOS) que usa la **ubicación que reporta el
agente de Applivery cada 15 minutos** y, con esa posición + la **API del UEM**,
ejecuta **acciones automáticas** (lock, wipe, message, locate, reboot…) cuando un
dispositivo entra/sale de una geovalla.

Funciona sin credenciales en **modo simulación** (flota sintética realista que se
mueve entre waypoints) y pasa a **modo live** en cuanto defines `APPLIVERY_API_KEY`.

## Arquitectura

```
Applivery agente ──(ubicación cada 15 min)──> UEM API
                                                    │
                          location_source (live poll cada 15 min)
                                                    │
                                          core/engine.py  ◀── fences.json
                                                    │  detecta transiciones
                                                    │  (entra/sale/viola)
                                                    ▼
                                  core/actions.py (adaptador UEM)
                                     lock / wipe / message / locate …
                                                    │
                          state_store (data/) ◀── dashboard (127.0.0.1:8765)
```

## MOAT — Geospatial Risk & Policy Engine (`core/policies.py`)

Lo que hace adquirible el producto: un UEM (Intune/Jamf/Applivery/Fleet) ya sabe
la ubicación del dispositivo. Si solo "dibujas geocercas y avisas", el UEM lo
absorbe en una sprint. El moat es modelar el **riesgo como función compuesta**:

    risk(device) = f(geofence_state, device_health, external_signals, time)

- `RiskEngine` calcula un **score 0-100** por dispositivo (no binario dentro/fuera).
- **Señales externas pluggable**: turno del trabajador, hora, riesgo de la zona
  (dataset local), salud/root/encryption del dispositivo. Se registran con
  `@register_signal("nombre")`.
- **Políticas compuestas**: "fuera de geocerca AND fuera de turno AND zona de
  riesgo → aislar". Cada decisión es explicable (trae sus señales → auditoría).
- Integrado en el ciclo del `Engine`: cada dispositivo se puntúa y las políticas
  que matchean disparan acciones UEM. El dashboard (`/api/risk`, `/api/policies`)
  muestra el score y las políticas disparadas.
- 100% local, sin exfiltrar datos. Dataset de ejemplo: `data/policies.json`.

## Módulo de Rutas — adherencia del comercial (`core/routes.py`)

Si asignas una **ruta comercial** (polilínea de waypoints + un corredor de
tolerancia en metros) a un dispositivo, el motor comprueba cada ciclo si está
**dentro del corredor** (`on_route`) o se ha salido (`off_route`). Cuando el
comercial abandona la ruta establecida **salta también**:

- Evento `route_exit` (transición `on_route → off_route`).
- **Acción automática** `notify` (o la que configures en la ruta), registrada en
  el log de acciones — visible en el dashboard.
- **+riesgo** vía `RiskEngine`: la señal `route_state` suma puntos cuando está
  `off_route` y los resta cuando vuelve a `on_route`.

La desviación se mide como la distancia mínima del dispositivo al segmento de
ruta más cercano (`core/geo.py: distance_to_segment_m`). El dashboard tiene una
vista **Rutas** (mapa con la polilínea + dispositivos coloreados por adherencia +
badge de desviación en metros). API: `GET /api/routes` (listar), `POST
/api/routes` (crear, cap `route:write`), `POST /api/routes/<id>/delete`
(eliminar). RBAC por capacidad: `owner/admin/operator` escriben, `viewer` solo
|lee.
|
|## Módulo de Workflows integrados (`core/workflows.py`)
|
|Apartado de **lógica lista para Applivery** pensado para el admin IT:
|
|- **Plantillas comunes ya hechas** (`TEMPLATES`): un click en el dashboard para
|  activarlas — p. ej. *Bloquear al salir de ruta*, *Wipe si rooteado fuera
|  de geocerca*, *Avisar CISO si desviación > 500 m*, *Aislar fuera de turno*,
|  *Localizar si señal perdida*. Cada una es una `Policy` (trigger + condiciones +
|  acción Applivery) lista para el motor.
|- **Creación fácil por admin IT** (`build_custom_policy`): un asistente de
|  formulario sencillo (disparador + condición + acción) **sin tocar JSON**.
|  El sistema normaliza el trigger/acción a la sintaxis `when`+`actions`.
|- Cada workflow se materializa en una `Policy` del `RiskEngine` y se ejecuta
|  contra el `LiveAdapter` de Applivery (`lock`/`wipe`/`message`/`locate`/
|  `reboot`/`clear_passcode`/`notify`/`custom`).
|- API: `GET /api/workflows` (plantillas + catálogo + activos),
|  `POST /api/workflows/apply` (activar plantilla), `POST /api/workflows/custom`
|  (crear fácil), `POST /api/workflows/<id>/delete`. RBAC: `workflow:read`
|  para listar, `workflow:write` para crear/activar/borrar.
|
|## Tests (TDD)
|
|```bash
|python3 tests/run_tests.py     # unit (rutas + workflows) + e2e HTTP (rutas + workflows)
|```
|
|Cubre: geometría de ruta, `on_route`/`off_route`, evento `route_exit`,
|plantillas de workflow, builder custom, create/delete de ruta/workflow, y QA
|end-to-end contra el server (endpoints 200, RBAC viewer bloqueado, `route_exit`
|dispara evento + acción, workflows se aplican y aparecen en activos).
|
|Ver test: `python3 _test_risk.py` (valida score + disparo de políticas).

## GTM / adquisición (assets en `gtm/`)
- `gtm/PRODUCT_BRIEF.md` — one-pager de posicionamiento on-prem-para-compliance.
- `gtm/ACQUISITION_NARRATIVE.md` — pitch de adquisición estilo YC.
- `gtm/VALIDATION_SCRIPT.md` — guion de las 5 llamadas que validan la suposición
  clave antes de construir más.

Carpeta `core/`:
- `geo.py`        — Haversine, punto-en-polígono, desplazamiento geográfico,
                     distancia a segmento de ruta.
- `state_store.py`— Persistencia local de estados, eventos y log de acciones.
- `fences.py`     — Modelo de geovalla (círculo o polígono) + acciones asociadas.
- `routes.py`     — Modelo de ruta comercial (polilínea + corredor) + adherencia.
- `location_source.py` — Live (polling real) y Simulation (flota demo).
- `actions.py`    — Ejecutor UEM: adaptador `live` (HTTP real) y `simulation`.
- `engine.py`     — Orquestador: fetch → evalúa → transiciones → acciones → registra.

## Puesta en marcha

```bash
cd ~/geofence-uem
chmod +x run.sh
./run.sh            # arranca motor + dashboard en http://127.0.0.1:8765
```

O bien por CLI:
```bash
python3 cli.py serve       # motor en bucle + dashboard
python3 cli.py run-once    # un ciclo y muestra stats
python3 cli.py watch       # ciclos en primer plano al intervalo configurado
python3 cli.py seed        # (re)crea la flota demo
```

Requiere Python 3.9+ y `requests` (`pip install requests`).

## Dashboard

Arranca con `./run.sh` (o `python3 cli.py serve` / `python3 saas_server.py`). Se abre
el **Command Center local multi-tenant** en http://127.0.0.1:8765. Al estar
vinculado exclusivamente a `127.0.0.1`, el dashboard crea automáticamente una
sesión demo local (sin formulario ni contraseña incrustada en el frontend); el
backend conserva autenticación y RBAC para todas las APIs.

El dashboard (Leaflet) muestra: Resumen, Mapa en vivo (geovallas + dispositivos),
Dispositivos, **Rutas** (adherencia del comercial), **Workflows integrados**
(plantillas Applivery + creación fácil), Risk Center, Políticas, Conformidad,
Facturación (mock), Usuarios y Ajustes. Botón “Forzar ciclo” para evaluar de
inmediato. En modo simulación el motor genera una flota sintética y corre solo
(autostart) — no necesitas credenciales para ver el producto funcionando.

## Modo live (datos reales de Applivery)

1. Copia `.env.example` a `.env` y pega tu `APPLIVERY_API_KEY` (Service Account
   con acceso a Organizations API).
2. En `config.json` pon `"mode": "live"` y tu `org_id` real.
3. El listado de dispositivos usa la ruta verificada
   `/v1/organizations/{org_id}/mdm/devices`. El envío de comandos remotos no está
   expuesto de forma estable en la API pública: el adaptador prueba el endpoint
   estándar y, ante cualquier no-2xx, delega de forma segura al
   `uem.remediation_webhook_url` configurado (sin provocar un 500).
4. El motor hace polling de ubicaciones cada `interval_seconds` (900 = 15 min) y
   evalúa las acciones configuradas en `fences.json`.

> Hasta que confirmes el endpoint exacto de comandos de dispositivo en tu tenant,
> mantén `"dry_run": true` para que las acciones se construyan pero no se envíen
> (verás `dry_run:true` en el log de acciones). Pon `"dry_run": false` solo cuando
> el endpoint esté validado.

## Geovallas y acciones

Edita `fences.json`. Cada geovalla soporta `circle` o `polygon` y una lista de
`actions` disparadas en `on_enter` / `on_exit` / `on_unknown`:

```json
{
  "id": "restricted-zone",
  "name": "Zona Restringida",
  "type": "circle",
  "center": { "lat": 40.3900, "lng": -3.7400 },
  "radius_m": 300,
  "actions": [
    { "action": "lock", "when": "on_enter", "enabled": true, "params": {} }
  ]
}
```

Acciones soportadas: `lock`, `wipe`, `message`, `locate`, `reboot`,
`clear_passcode`, `custom`.

## Datos locales

Todo vive en `data/` (estados, eventos, acciones, semilla demo). Sin nada en la
nube salvo las llamadas a la API de Applivery cuando estás en modo live.
