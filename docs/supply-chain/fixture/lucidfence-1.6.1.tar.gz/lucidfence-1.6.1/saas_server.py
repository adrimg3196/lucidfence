#!/usr/bin/env python3
"""SaaS HTTP server for LucidFence — 100% local, multi-tenant.

This server wraps the existing single-fleet engine and adds the SaaS layer:
- Authentication (login/signup/logout) with session cookies
- Multi-tenant organizations, each with its own isolated data dir + engine
- RBAC enforced per endpoint
- REST API for every product module (map, devices, fences, risk, policies,
  compliance, analytics, reports, users, settings)
- Free forever: no paid plans, no billing (donations via .github/FUNDING.yml)

Nothing leaves the machine. Runs on 127.0.0.1.

Routes (auth):
  POST /api/auth/signup      body {email,name,password,org_name} -> {token,user,org}
  POST /api/auth/login       body {email,password} -> {token,user}
  POST /api/auth/logout
  GET  /api/auth/me          -> current user + orgs (requires session)

Routes (orgs, require session):
  POST /api/orgs/<id>/switch -> sets active org cookie
  GET  /api/org              -> active org profile + plan + limits

Routes (product, require session + capability + scoped to active org):
  GET  /api/status
  POST /api/run-once
  GET  /api/devices  (+ ?state=)
  GET  /api/devices/<id>
  GET  /api/fences           -> fence IDs only (geometry comes from /api/status.st.fences)
  GET  /api/risk
  GET  /api/coverage         -> informe de puntos ciegos (cobertura en negativo)
  GET  /api/fleet/federated  -> flota federada multi-UEM (+ ?provider=)
  GET  /api/least-privilege  -> auditoría de privilegios de las credenciales UEM
  GET  /api/incidents
  GET  /api/policies
  GET  /api/analytics
  GET  /api/compliance
  GET  /api/report
  GET  /api/users            (owner/admin) list org users
  POST /api/users            (owner/admin) invite user
  GET  /api/settings/status
  POST /api/settings         save credentials
  POST /api/settings/test

Static dashboard served at /.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import mimetypes
import os
import sys
import threading
import time
from email.utils import formatdate
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from socketserver import TCPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from typing import Any, Optional

# make sure the 'lucidfence' package and its siblings are importable
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from lucidfence.core import config_loader
from lucidfence.core import cloud_publisher
from lucidfence.saas.tenant import TenantStore, FREE_PLAN
from lucidfence.saas.auth import AuthStore, ROLE_LABELS, ROLE_CAPS
from lucidfence.saas import routing
from lucidfence.core.oidc import (OIDCClient, OIDCError, OIDCFlowStore, OIDCProvider,
                       PinnedHTTPSTransport, oidc_dependencies_available)
from lucidfence.core.engine import Engine
from lucidfence.core.product import build_product
from lucidfence.core import secrets as core_secrets
from lucidfence.core import ai_provider
from lucidfence.core import workflows as WF  # workflows module (templates + custom builder)
from lucidfence.core.actions import VALID_ACTIONS
from lucidfence.core.alerts import ALERT_TYPES, CHANNELS, ALERT_TYPE_LABELS
from lucidfence.core.app_paths import ensure_data_dir
from lucidfence.core.api_keys import APIKeyStore, append_audit, verify_audit
from lucidfence.core.compliance_controls import map_controls
from lucidfence.core.cluster import ClusterLease
from lucidfence.core.autonomous_company import CompanyControlPlane
from lucidfence.core.poi import POIService

STATIC = ROOT / "static"
TEMPLATE_DATA = ROOT / "data"
CONFIG_FILE = ROOT / os.environ.get("LUCIDFENCE_CONFIG_FILE", "config.json")
DATA_ROOT = ensure_data_dir()
COOKIE_SESSION = "gf_session"
COOKIE_ORG = "gf_org"
COOKIE_OIDC_PREAUTH = "gf_oidc_pre"
RATE_LIMIT_REQUESTS = int(os.environ.get("LUCIDFENCE_RATE_LIMIT_REQUESTS", "120") or "120")
RATE_LIMIT_WINDOW_S = int(os.environ.get("LUCIDFENCE_RATE_LIMIT_WINDOW_S", "60") or "60")
_rate_limit_buckets: dict[str, list[float]] = {}
_rate_limit_lock = threading.Lock()
_metrics_lock = threading.Lock()
_request_counts: dict[str, int] = {}
MAX_REQUEST_BODY = 1024 * 1024

# Global stores for the local app. Runtime data never lives in Homebrew's
# Cellar nor in the source checkout unless LUCIDFENCE_DATA_DIR explicitly says so.
_tenants = TenantStore(DATA_ROOT)
_auth = AuthStore(DATA_ROOT)

# POIs: seed público read-only (data/pois.json), opcional. Fail-soft si falta
# o está corrupto — el resto del servidor no depende de él.
_poi_service = POIService()
try:
    _pois_seed = TEMPLATE_DATA / "pois.json"
    if _pois_seed.exists():
        _poi_service.load_from_json(_pois_seed)
except Exception:
    pass
def _load_oidc_providers() -> dict[str, OIDCProvider]:
    """Load deployment-only OIDC configuration; never values from requests."""
    providers: dict[str, OIDCProvider] = {}
    google = OIDCProvider.google(
        client_id=os.environ.get("LUCIDFENCE_GOOGLE_CLIENT_ID", ""),
        client_secret=os.environ.get("LUCIDFENCE_GOOGLE_CLIENT_SECRET", ""),
        redirect_uri=os.environ.get("LUCIDFENCE_GOOGLE_REDIRECT_URI", ""),
        allowed_domains=tuple(filter(None, os.environ.get("LUCIDFENCE_GOOGLE_ALLOWED_DOMAINS", "").split(","))),
        provision_org_id=os.environ.get("LUCIDFENCE_GOOGLE_PROVISION_ORG_ID", ""),
    )
    providers[google.name] = google
    raw = os.environ.get("LUCIDFENCE_OIDC_PROVIDERS_JSON", "").strip()
    if raw:
        try:
            rows = json.loads(raw)
            if not isinstance(rows, list) or len(rows) > 16:
                raise ValueError
            for row in rows:
                if not isinstance(row, dict):
                    raise ValueError
                item = OIDCProvider(**row)
                providers[item.name] = item
        except (ValueError, TypeError, OIDCError, json.JSONDecodeError):
            raise RuntimeError("invalid OIDC provider configuration") from None
    return providers


_oidc_providers = _load_oidc_providers()
_oidc_flows = OIDCFlowStore(DATA_ROOT / "_oidc_flows.json", lock=_auth._lock)
_oidc_client = OIDCClient(_oidc_providers, _oidc_flows, PinnedHTTPSTransport())


def _validate_oidc_startup(providers: dict[str, OIDCProvider], host: str, port: int) -> None:
    enabled = [provider for provider in providers.values() if provider.enabled]
    if enabled and not oidc_dependencies_available():
        raise RuntimeError("OIDC dependencies unavailable")
    for provider in enabled:
        if not provider.local_public_client:
            continue
        redirect = urlparse(provider.redirect_uri)
        if redirect.hostname != host or redirect.port != port:
            raise RuntimeError("OIDC local redirect must match server listener")


_api_keys = APIKeyStore(DATA_ROOT)
# Seed de la cuenta demo para que la vitrina/CI puedan autenticarse sin
# configuracion manual (ciso@acme.test / demo1234). Idempotente: si el
# usuario ya existe, no hace nada. Si el tenant demo no existe, lo crea.
try:
    if _auth.get_by_email("ciso@acme.test") is None:
        _demo_org = None
        for o in _tenants.all():
            if o.slug == "acme-logistics":
                _demo_org = o
                break
        if _demo_org is None:
            _demo_org = _tenants.create("Acme Logistics (demo)", "usr_demo_seed")
        _auth.create_user("ciso@acme.test", "CISCO Acme (demo)", "demo1234",
                          _demo_org.id, "owner")
except Exception:
    pass
_SIMULATION = False

# Per-org engine cache. Each org gets its own running engine.
_engines: dict[str, Engine] = {}
_engines_lock = threading.Lock()
_cluster_lease: ClusterLease | None = None


def _apply_tenant_integration(cfg: dict, tdir: Path) -> dict:
    """Overlay tenant-local credentials/mode without leaking another org's key."""
    key = core_secrets.read_key(tdir)
    workspace_id = core_secrets.read_org_id(tdir)
    runtime = {}
    runtime_path = tdir / "integration.json"
    try:
        runtime = json.loads(runtime_path.read_text(encoding="utf-8"))
    except Exception:
        runtime = {}
    configured = bool(key and workspace_id)
    mode = runtime.get("mode")
    if mode not in ("live", "simulation"):
        mode = "live" if configured else "simulation"
    if mode == "live" and not configured:
        mode = "simulation"
    cfg["mode"] = mode
    cfg["dry_run"] = bool(runtime.get("dry_run", cfg.get("dry_run", True)))
    # Fase de enforcement (observe|enforce): editable por un admin desde el
    # dashboard y persistida por tenant aquí. Sobreescribe `mode` dentro del
    # bloque enforcement, que el Engine usa para fijar dry_run; live_actions,
    # allow_wipe y wipe_allowlist siguen viniendo de config.json (la doble
    # llave del wipe nunca se amplía desde la UI).
    enf_mode = runtime.get("enforcement_mode")
    if enf_mode in ("observe", "enforce"):
        base_enf = dict(cfg.get("enforcement") or {})
        base_enf["mode"] = enf_mode
        cfg["enforcement"] = base_enf
    cfg["_applivery_api_key"] = key
    cfg.setdefault("applivery", {})["org_id"] = workspace_id
    cfg["incident_webhook_url"] = (runtime.get("incident_webhook_url") or "").strip()
    # Per-tenant outbound webhook egress policy (t_f33e2f23). Opt-in `strict`
    # mode adds an allow-list on top of the admission guard; default is
    # `permissive` (current behaviour — never breaks existing deployments).
    _egress = runtime.get("egress_policy")
    if isinstance(_egress, dict) and _egress:
        cfg["egress_policy"] = _egress
    # Atomic Mail Agentic: real email for the SaaS (opt-in per tenant).
    am = runtime.get("atomicmail") or {}
    if isinstance(am, dict) and am:
        cfg["atomicmail"] = {k: v for k, v in am.items() if v not in (None, "")}
    # Whitelabel domain (DigitalPlat FreeDomain) used as the sender/branding
    # domain for sovereign email (paired with Atomic Mail's DKIM).
    wl = runtime.get("whitelabel") or {}
    if isinstance(wl, dict) and wl.get("domain"):
        cfg["whitelabel"] = {k: v for k, v in wl.items() if v not in (None, "")}
    # Multi-UEM: build the provider list from tenant-isolated integration.json.
    # The secret stays on disk (0600) and is passed straight to the adapter; it
    # is never echoed back by GET /api/providers (see _masked_provider).
    providers = []
    for p in runtime.get("providers", []) or []:
        if not isinstance(p, dict) or not p.get("name"):
            continue
        providers.append({
            "name": p["name"],
            "org_id": p.get("org_id", ""),
            "endpoint": p.get("endpoint", ""),
            "api_key": p.get("secret", "") or p.get("api_key", ""),
        })
    cfg["providers"] = providers
    return cfg


def _save_tenant_integration(tdir: Path, mode: str, dry_run: bool,
                             incident_webhook_url: str = "",
                             atomicmail: dict | None = None,
                             whitelabel: dict | None = None,
                             egress_policy: dict | None = None) -> None:
    path = tdir / "integration.json"
    runtime = {}
    try:
        runtime = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        runtime = {}
    runtime["mode"] = mode
    runtime["dry_run"] = bool(dry_run)
    if incident_webhook_url is not None:
        if incident_webhook_url:
            runtime["incident_webhook_url"] = incident_webhook_url.strip()
        else:
            runtime.pop("incident_webhook_url", None)
    if atomicmail is not None:
        # atomicmail carries the tenant's Atomic Mail config (username / api_key
        # / recipient). Strip empty values; the api_key is a secret and lives in
        # this tenant-local, chmod 0600 file only.
        cleaned = {k: v for k, v in (atomicmail or {}).items() if v not in (None, "")}
        if cleaned:
            runtime["atomicmail"] = cleaned
        else:
            runtime.pop("atomicmail", None)
    if whitelabel is not None:
        # whitelabel = tenant's FreeDomain domain + dkim selector, used as the
        # sender/branding domain for sovereign email. domain is not secret.
        cleaned = {k: v for k, v in (whitelabel or {}).items() if v not in (None, "")}
        if cleaned:
            runtime["whitelabel"] = cleaned
        else:
            runtime.pop("whitelabel", None)
    if egress_policy is not None:
        # Persist the validated per-tenant egress policy (t_f33e2f23). Validation
        # happens at the API layer (_validate_egress_policy); here we only store
        # a well-formed dict. An empty/invalid value clears the policy (back to
        # permissive default).
        if isinstance(egress_policy, dict) and egress_policy:
            runtime["egress_policy"] = egress_policy
        else:
            runtime.pop("egress_policy", None)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(runtime, indent=2), encoding="utf-8")
    os.chmod(tmp, 0o600)
    tmp.replace(path)
    os.chmod(path, 0o600)


def _tenant_runtime(tdir: Path) -> dict:
    try:
        data = json.loads((tdir / "integration.json").read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


# --- Multi-UEM provider registry (per tenant, isolated dir) ----------------
# Logic lives in lucidfence.saas.providers so it's unit-testable without the
# server process. The provider *list* (names + non-secret config + secret)
# lives in integration.json (tenant-isolated, chmod 0600); masked on GET.
from lucidfence.saas.providers import list_providers as _list_providers
from lucidfence.saas.providers import save_providers as _save_providers

# Todas las claves que pueden portar un secreto de conexión. Ninguna sale nunca
# en un GET (ni en el audit log): las credenciales viven en integration.json
# (0600) y jamás se re-emiten al cliente.
_PROVIDER_SECRET_KEYS = ("secret", "api_key", "api_token", "client_secret",
                         "refresh_token", "password", "token")


def _provider_health(eng: "Engine | None") -> dict:
    if eng is None or getattr(eng, "orchestrator", None) is None:
        return {}
    try:
        return {n: h.status for n, h in eng.orchestrator.health().items()}
    except Exception:
        return {}


def _masked_provider(p: dict) -> dict:
    # Elimina TODA clave que porte un secreto (no solo "secret": Intune/Jamf/
    # ChromeOS guardan client_secret/refresh_token). `segment` (la etiqueta de
    # flota: móviles/portátiles/…) no es secreto y se conserva para la UI.
    out = {k: v for k, v in p.items() if k not in _PROVIDER_SECRET_KEYS}
    # `scopes` NO es secreto (son permisos declarados, no credenciales), pero
    # sale aparte: el veredicto del auditor de mínimo privilegio está tras
    # `engine:config` porque dice en voz alta qué tokens pueden wipear — y de
    # los nombres de scope ese veredicto se deriva trivialmente. Dejarlos en
    # este GET (sin cap propia) convertiría ese gating en teatro. Se sirven en
    # GET /api/least-privilege, con su cap.
    out.pop("scopes", None)
    out["configured"] = bool(p.get("secret") or p.get("api_key")
                             or p.get("api_token") or p.get("password")
                             or p.get("client_secret") or p.get("refresh_token")
                             or p.get("endpoint") or p.get("tenant_id"))
    return out


def _masked_secret(secret: str) -> str:
    secret = secret or ""
    if not secret:
        return ""
    if len(secret) <= 8:
        return "*" * len(secret)
    return "*" * (len(secret) - 4) + secret[-4:]


def _header(headers, name: str) -> str:
    for key in (name, name.lower(), name.upper()):
        try:
            value = headers.get(key)
        except Exception:
            value = None
        if value:
            return str(value).strip()
    return ""


def _verify_soar_webhook_hmac(raw_body: bytes, headers, secret: str,
                              now: float | None = None,
                              tolerance_seconds: int = 300) -> tuple[bool, str]:
    """Validate inbound SOAR webhook HMAC with timestamp anti-replay.

    Contract: X-LucidFence-Timestamp contains unix seconds and
    X-LucidFence-Signature (or X-Hub-Signature-256) contains the hex HMAC-SHA256
    of ``<timestamp>.<raw_body>`` using the tenant's SOAR webhook secret.
    Accepted signature wrappers: ``sha256=<hex>`` or ``v1=<hex>``.
    """
    if not secret:
        return False, "soar webhook secret not configured"
    ts = _header(headers, "X-LucidFence-Timestamp")
    if not ts:
        return False, "missing timestamp"
    try:
        ts_float = float(ts)
    except (TypeError, ValueError):
        return False, "invalid timestamp"
    now = time.time() if now is None else now
    if abs(now - ts_float) > tolerance_seconds:
        return False, "timestamp outside replay window"
    signature = _header(headers, "X-LucidFence-Signature") or _header(headers, "X-Hub-Signature-256")
    if not signature:
        return False, "missing signature"
    if "=" in signature:
        algo, _, signature = signature.partition("=")
        if algo not in ("sha256", "v1"):
            return False, "unsupported signature algorithm"
    signature = signature.strip().lower()
    if len(signature) != 64:
        return False, "invalid signature length"
    signed = ts.encode("utf-8") + b"." + (raw_body or b"")
    expected = hmac.new(secret.encode("utf-8"), signed, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, signature):
        return False, "invalid signature"
    return True, "ok"


_REQUIRED_TENANT_SEEDS = ("routes.json", "policies.json", "fleet_seed.json", "fences.json")
_OPTIONAL_TENANT_SEEDS = ("device_overrides.json",)


def _seed_tenant_defaults(tdir: Path) -> None:
    """Copy immutable packaged templates into a new tenant data directory."""
    tdir.mkdir(parents=True, exist_ok=True)
    for name in (*_REQUIRED_TENANT_SEEDS, *_OPTIONAL_TENANT_SEEDS):
        src = TEMPLATE_DATA / name
        dst = tdir / name
        if dst.exists():
            continue
        if not src.is_file():
            if name in _REQUIRED_TENANT_SEEDS:
                raise FileNotFoundError(f"LucidFence package is missing required seed: {src}")
            continue
        raw = src.read_text(encoding="utf-8")
        json.loads(raw)
        temp = dst.with_name(f".{dst.name}.{os.getpid()}.tmp")
        try:
            temp.write_text(raw, encoding="utf-8")
            os.chmod(temp, 0o600)
            os.replace(temp, dst)
        finally:
            temp.unlink(missing_ok=True)


def engine_for(org_id: str) -> Engine:
    with _engines_lock:
        if org_id in _engines:
            return _engines[org_id]
        cfg = config_loader.load(CONFIG_FILE)
        # point data dir at the tenant's isolated directory
        tdir = _tenants.data_dir(org_id)
        cfg["data_dir"] = str(tdir)
        # seed per-tenant defaults once so each org starts with the demo data
        # but remains isolated afterwards (this is what makes it a real SaaS)
        _seed_tenant_defaults(tdir)
        cfg["fences_path"] = str(tdir / "fences.json")
        cfg["routes_path"] = str(tdir / "routes.json")
        cfg["policies_path"] = str(tdir / "policies.json")
        cfg["sim_seed_path"] = str(tdir / "fleet_seed.json")
        cfg = _apply_tenant_integration(cfg, tdir)
        eng = Engine(cfg)
        eng.tenant_id = org_id
        if cfg.get("autostart", True):
            eng.start()
        _engines[org_id] = eng
        return eng


def _company_context(eng: Engine) -> dict:
    """Build a bounded, secret-free evidence snapshot for one company cycle."""
    devices = list(eng.store.snapshot().values())
    known_compliance = [item for item in devices if item.compliant is not None]
    compliant = sum(1 for item in known_compliance if item.compliant is True)
    critical_apps = 0
    for device in devices:
        for app in device.apps or []:
            cves = app.get("cves") or app.get("vulnerabilities") or []
            if any(str(cve.get("severity") or "").lower() == "critical" for cve in cves if isinstance(cve, dict)):
                critical_apps += 1
    try:
        open_incidents = len(eng.incidents.list(status="open"))
    except Exception:
        open_incidents = 0
    return {
        "devices": len(devices),
        "outside": sum(1 for item in devices if item.fence_state == "outside"),
        "unknown": sum(1 for item in devices if item.fence_state == "unknown"),
        "high_risk": sum(1 for item in devices if item.risk_severity in {"high", "critical"}),
        "critical_cve_apps": critical_apps,
        "open_incidents": open_incidents,
        "compliance_percent": round(100 * compliant / len(known_compliance), 1) if known_compliance else 100.0,
    }


def reload_engine(org_id: str) -> Engine:
    """Rebuild the cached engine for an org from the current config/.env.

    Used after the operator saves new Applivery credentials or flips the mode
    in Settings, so the live integration takes effect without a full restart.
    """
    with _engines_lock:
        old = _engines.pop(org_id, None)
        if old is not None:
            try:
                old.stop()
            except Exception:
                pass
        cfg = config_loader.load(CONFIG_FILE)
        tdir = _tenants.data_dir(org_id)
        cfg["data_dir"] = str(tdir)
        _seed_tenant_defaults(tdir)
        cfg["fences_path"] = str(tdir / "fences.json")
        cfg["routes_path"] = str(tdir / "routes.json")
        cfg["policies_path"] = str(tdir / "policies.json")
        cfg["sim_seed_path"] = str(tdir / "fleet_seed.json")
        cfg = _apply_tenant_integration(cfg, tdir)
        eng = Engine(cfg)
        eng.tenant_id = org_id
        if cfg.get("autostart", True):
            eng.start()
        _engines[org_id] = eng
        return eng


def user_from_request(handler) -> Optional[dict]:
    token = _cookie(handler, COOKIE_SESSION)
    if token:
        sess = _auth.get_session(token)
        if sess:
            u = _auth.get(sess["user_id"])
            if u and u.active:
                return u.to_public()
    authorization = (handler.headers.get("Authorization") or "").strip()
    if authorization.startswith("Bearer lf_"):
        record = _api_keys.authenticate(authorization[7:])
        if record:
            return {
                "id": "apikey:" + str(record["id"]),
                "email": "",
                "name": str(record.get("name") or "API key"),
                "active": True,
                "org_roles": {str(record["org_id"]): str(record["role"])},
                "auth_type": "api_key",
            }
    # No anonymous fallback. La dashboard local obtiene una sesión real con
    # RBAC vía /api/auth/login; toda llamada API requiere esa cookie de sesión.
    # (No hay endpoint demo: un request no autenticado nunca se trata como
    # owner del demo — vé test_frontend_contract seguridad.)
    return None


def active_org(handler, user) -> Optional[str]:
    org = _cookie(handler, COOKIE_ORG)
    if org:
        # Strict: only honor an explicit org cookie if it belongs to the user.
        # Fall back to the first org only when no cookie is set, never when the
        # cookie names an org the user is not a member of (prevents cross-org
        # escalation via a forged gf_org cookie).
        if org in user["org_roles"]:
            return org
        return None
    # fall back to first org
    if user["org_roles"]:
        return next(iter(user["org_roles"]))
    return None


def require(handler, cap: Optional[str] = None):
    """Return (user, org) or send 401/403 and return None."""
    user = user_from_request(handler)
    if not user:
        _send_json(handler, {"error": "no autenticado"}, 401)
        return None
    org = active_org(handler, user)
    if not org:
        _send_json(handler, {"error": "sin organización activa"}, 403)
        return None
    if cap:
        role = user["org_roles"].get(org)
        if not AuthStore.can(role, cap):
            _send_json(handler, {"error": "sin permiso", "capability": cap}, 403)
            return None
    return user, org


def _cookie(handler, name: str) -> Optional[str]:
    for c in handler.headers.get_all("Cookie") or []:
        for part in c.split(";"):
            k, _, v = part.strip().partition("=")
            if k == name:
                return v
    return None


def _host_allowed(handler) -> bool:
    """Reject requests whose Host header points elsewhere (DNS-rebinding /
    CSRF against a non-loopback bind). Allow loopback + configured host."""
    import os
    host = (handler.headers.get("Host") or "").split(":")[0].strip().lower()
    if not host:
        return True  # let non-HTTP/1.1 or missing header through (server decides)
    allowed = {"127.0.0.1", "localhost", "::1",
               (os.environ.get("LUCIDFENCE_HOST") or "").lower()}
    allowed.discard("")
    if host in allowed:
        return True
    # allow a configured public host (e.g. behind a reverse proxy)
    cfg_host = ""
    try:
        cfg_host = (handler.server and getattr(handler.server, "lucidfence_host", "")) or ""
    except Exception:
        cfg_host = ""
    return host == cfg_host.lower()


def _bound_host(handler) -> str:
    address = getattr(getattr(handler, "server", None), "server_address", None)
    if isinstance(address, tuple) and address:
        return str(address[0]).strip().lower()
    return ""


def _gateway_allowed(handler) -> bool:
    """Allow anonymous OpenAI-compatible traffic only on a loopback bind."""
    loopback = {"127.0.0.1", "localhost", "::1"}
    bound = _bound_host(handler)
    client = (handler.client_address[0] if handler.client_address else "").lower()
    if bound in loopback and client in loopback:
        return True
    expected = os.environ.get("LUCIDFENCE_GATEWAY_TOKEN", "")
    supplied = handler.headers.get("Authorization", "")
    return len(expected) >= 16 and hmac.compare_digest(supplied, "Bearer " + expected)


def _gateway_tenant(handler):
    """Resolve an explicit org, otherwise the first org with AI configured."""
    requested = (handler.headers.get("X-LucidFence-Org", "") or "").strip()
    if requested and _tenants.get(requested):
        return requested
    for item in _tenants.all():
        if ai_provider.status(_tenants.data_dir(item.id)).get("configured"):
            return item.id
    return None


def _client_ip(handler) -> str:
    """Best-effort client IP for rate-limiting.

    Direct always-on deployments use the socket peer. Reverse-proxy deployments
    may opt into forwarded headers with LUCIDFENCE_TRUST_PROXY=1.
    """
    if os.environ.get("LUCIDFENCE_TRUST_PROXY") == "1":
        xff = (handler.headers.get("X-Forwarded-For") or "").split(",")[0].strip()
        if xff:
            return xff
        xri = (handler.headers.get("X-Real-IP") or "").strip()
        if xri:
            return xri
    try:
        return str(handler.client_address[0])
    except Exception:
        return "unknown"


def _rate_limit_key(handler) -> str:
    """Bucketing for the rate limiter.

    A raw ``gf_session`` cookie is ONLY trusted as a bucket key when it
    corresponds to a live session in AuthStore. An unauthenticated client can
    mint a different cookie per request; using the raw cookie value would give
    every request a fresh bucket and fully bypass the limiter. So we validate
    the token against AuthStore first, and fall back to the source IP (which
    the limiter already keys on) when there is no valid session.

    This is a security fix (SOC audit 2026-08-20, H-1): the previous code
    derived the bucket from the *raw* cookie value before any authentication,
    so rotating the cookie bypassed the only anti-DoS / anti-enumeration guard.
    """
    token = _cookie(handler, COOKIE_SESSION) or ""
    if token:
        sess = _auth.get_session(token)
        if sess:
            digest = hashlib.sha256(token.encode("utf-8")).hexdigest()[:16]
            return f"sess:{digest}"
    # No valid session: bucket by source IP. Authenticated-but-token-invalid
    # requests also land here, which is correct — the IP limit still applies.
    return f"ip:{_client_ip(handler)}"


def _rate_limit_required(handler) -> bool:
    try:
        route = urlparse(handler.path).path
    except Exception:
        return True
    if route in ("/api/health", "/api/healthz", "/api/readyz"):
        return False
    return route.startswith("/api/") or route.startswith("/v1/")


def _rate_limit_check(handler, now: float | None = None) -> tuple[bool, int, str]:
    limit = RATE_LIMIT_REQUESTS
    window = RATE_LIMIT_WINDOW_S
    if limit <= 0 or window <= 0 or not _rate_limit_required(handler):
        return True, 0, ""
    now = time.time() if now is None else now
    cutoff = now - window
    key = _rate_limit_key(handler)
    with _rate_limit_lock:
        bucket = [ts for ts in _rate_limit_buckets.get(key, []) if ts > cutoff]
        if len(bucket) >= limit:
            retry_after = max(1, int(bucket[0] + window - now) + 1)
            _rate_limit_buckets[key] = bucket
            return False, retry_after, key
        bucket.append(now)
        _rate_limit_buckets[key] = bucket
        # Opportunistic cleanup keeps the in-memory limiter bounded for
        # always-on usage without a background thread.
        if len(_rate_limit_buckets) > 4096:
            stale = [k for k, vals in _rate_limit_buckets.items()
                     if not vals or vals[-1] <= cutoff]
            for k in stale[:1024]:
                _rate_limit_buckets.pop(k, None)
        return True, 0, key


def _send_rate_limited(handler, retry_after: int):
    body = json.dumps({"error": "rate_limit", "retry_after": retry_after},
                      ensure_ascii=False, indent=2).encode("utf-8")
    handler.send_response(429)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("Retry-After", str(retry_after))
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("X-Content-Type-Options", "nosniff")
    handler.end_headers()
    handler.wfile.write(body)


def _set_cookie(handler, name: str, value: str, max_age: int = 60 * 60 * 24 * 7):
    # Accumulate; emitted inside _send_json AFTER send_response (Python 3.9
    # flush-order quirk: send_header before send_response leaks the header first)
    lst = getattr(handler, "_set_cookies", None)
    if lst is None:
        lst = handler._set_cookies = []
    secure = ""
    try:
        proto = (handler.headers.get("X-Forwarded-Proto") or "").lower()
        if proto == "https" or os.environ.get("LUCIDFENCE_TLS") == "1":
            secure = "Secure; "
    except Exception:
        secure = ""
    expires = formatdate(time.time() + max_age, usegmt=True)
    lst.append(f"{name}={value}; Path=/; HttpOnly; {secure}SameSite=Strict; Max-Age={max_age}; Expires={expires}")


def _clear_cookie(handler, name: str):
    lst = getattr(handler, "_set_cookies", None)
    if lst is None:
        lst = handler._set_cookies = []
    lst.append(f"{name}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT")


def _set_oidc_cookie(handler, name: str, value: str, max_age: int):
    """Host-only OIDC cookie. Proxy headers are intentionally not trusted."""
    lst = getattr(handler, "_set_cookies", None)
    if lst is None:
        lst = handler._set_cookies = []
    secure = "Secure; " if os.environ.get("LUCIDFENCE_TLS") == "1" else ""
    expires = formatdate(time.time() + max_age, usegmt=True)
    lst.append(f"{name}={value}; Path=/; HttpOnly; {secure}SameSite=Lax; Max-Age={max_age}; Expires={expires}")


def _send_redirect(handler, location: str, code: int, *, no_referrer: bool = False):
    handler.send_response(code)
    handler.send_header("Location", location)
    handler.send_header("Cache-Control", "no-store")
    if no_referrer:
        handler.send_header("Referrer-Policy", "no-referrer")
    for cookie in getattr(handler, "_set_cookies", []) or []:
        handler.send_header("Set-Cookie", cookie)
    handler._set_cookies = []
    handler.send_header("Content-Length", "0")
    handler.end_headers()


def _redact_access_path(path: str) -> str:
    marker = "/api/auth/sso/"
    if marker in path and "/callback?" in path:
        return path.split("?", 1)[0] + "?[REDACTED]"
    return path


# SSRF guard: only https, never loopback/link-local/metadata targets, on an
# explicit outbound port allowlist. Residual after the 2026-08-18 numeric-IP
# fix: a public DNS name that resolves to an internal IP still passed, and there
# was no port restriction. This version resolves the hostname to ALL addresses
# and rejects if ANY resolves to loopback / link-local (incl. cloud metadata
# 169.254.0.0/16) / reserved, which closes the metadata-exfil and
# loopback-DNS-rebinding PoCs. See the allowlist note below for the RFC1918
# trade-off.
_WEBHOOK_ALLOWED_PORTS = {443, 8443}


def _safe_webhook_url(url: str):
    """SSRF guard: only https, never loopback/link-local/metadata targets.

    Returns the normalized URL or '' if unsafe/unusable.

    Defense layers (combined across the 2026-08-18 and 2026-08-20 audits):
      1. scheme must be https
      2. numeric IP encodings (2130706433 / 0x7f000001 / 127.1 ...) are
         canonicalized via getaddrinfo(AI_NUMERICHOST) so they hit the same
         loopback/link-local/reserved filter as canonical IPs
      3. a public hostname is resolved with a real DNS lookup and EVERY
         returned address is validated; loopback/link-local/metadata/reversed
         addresses are rejected (closes "public name -> 169.254.169.254")
      4. the port must be on the explicit outbound allowlist (443 / 8443)

    Trade-off (documented, not a bug): an unresolvable hostname (e.g. a LAN
    name like fleet.acme.test that only resolves inside the customer's network)
    is ALLOWED, and RFC1918 private ranges are intentionally NOT blocked on
    resolution. LucidFence is a local-first UEM appliance whose own endpoints
    (Intune/Jamf/Workspace ONE/Applivery) are routinely on private IPs or
    internal hostnames the operator legitimately configures. The real SSRF
    pivot targets (loopback, cloud metadata, link-local) are blocked. A stricter
    "block all private resolution + pin DNS + 443-only" variant is a follow-up
    that needs product sign-off because it would break on-prem UEM.
    """
    from urllib.parse import urlparse
    if not url:
        return ""
    try:
        p = urlparse(url)
    except Exception:
        return ""
    if p.scheme != "https":
        return ""
    host = (p.hostname or "").lower()
    if not host:
        return ""
    port = p.port if p.port is not None else 443
    if port not in _WEBHOOK_ALLOWED_PORTS:
        return ""
    import ipaddress
    import socket
    # Canonicaliza encodings numéricos de IP (decimal/hex/octal/dotless, p.ej.
    # 2130706433 / 0x7f000001 / 017700000001 / 127.1 == 127.0.0.1; 2852039166 ==
    # 169.254.169.254) que glibc getaddrinfo acepta pero ipaddress rechaza. Sin
    # esto, un destino interno escrito en forma no canónica se colaba por la rama
    # `except ValueError` como "hostname externo". AI_NUMERICHOST NO hace lookup
    # DNS: un hostname real lanza gaierror y se deja intacto (fleet.acme.test no
    # se rompe). Hallazgo del Centinela 2026-08-18 (SSRF bypass).
    try:
        host = socket.getaddrinfo(host, None, flags=socket.AI_NUMERICHOST)[0][4][0].lower()
    except socket.gaierror:
        pass
    try:
        ip = ipaddress.ip_address(host)
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            return ""
        mapped = getattr(ip, "ipv4_mapped", None)
        if mapped and (mapped.is_private or mapped.is_loopback
                       or mapped.is_link_local or mapped.is_reserved):
            return ""
        return url
    except ValueError:
        # Hostname (not IP). Block obvious internal suffixes even if they are
        # publicly resolvable — `.internal`/`.lan`/`.home` are real public-suffix
        # TLDs an attacker can register, and `localhost` is always loopback. This
        # closes the "evil.attacker.internal" pivot on top of the resolution
        # check below. (SOC audit 2026-08-20, H-3.)
        if host.endswith((".local", ".internal", ".lan", ".home")) or host == "localhost":
            return ""
        # resolve it for real and validate EVERY address.
        # Reject only loopback / link-local (incl. cloud metadata) / reserved /
        # multicast — the genuine SSRF pivot targets. Unresolvable LAN names and
        # RFC1918 results are allowed (see trade-off note above).
        try:
            infos = socket.getaddrinfo(host, None)
        except socket.gaierror:
            # Unresolvable here (e.g. an internal LAN name) — allow; the operator
            # configured it and it is not a loopback/metadata pivot.
            return url
        except (UnicodeError, OSError):
            return ""
        if not infos:
            return ""
        for info in infos:
            addr = str(info[4][0]).lower()
            # IPv6 scoped/zone handling: strip zone id.
            addr = addr.split("%", 1)[0]
            try:
                ip = ipaddress.ip_address(addr)
            except ValueError:
                return ""
            if (ip.is_loopback or ip.is_link_local or ip.is_reserved
                    or ip.is_multicast):
                return ""
            mapped = getattr(ip, "ipv4_mapped", None)
            if mapped and (mapped.is_loopback or mapped.is_link_local
                           or mapped.is_reserved):
                return ""
        return url


def _validate_egress_policy(raw: Any) -> tuple[bool, str, dict]:
    """Validate a tenant egress policy payload sent from the dashboard.

    Returns (ok, error_message, normalized_policy). An empty/absent policy is
    valid and means "permissive" (current behaviour). A `*`` wildcard entry is
    rejected because it would be an allow-all that nullifies the policy.

    Format (see DECISION_EGRESS_ALLOWLIST.md / t_316b8ec5):
        {"mode": "permissive"|"strict",
         "allow": ["hooks.slack.com", ".slack.com", "10.20.30.40"],
         "allow_private": false}
    """
    if raw is None:
        return True, "", {}
    if not isinstance(raw, dict):
        return False, "egress_policy debe ser un objeto", {}
    mode = str(raw.get("mode", "permissive")).strip().lower()
    if mode not in ("permissive", "strict"):
        return False, "egress_policy.mode debe ser 'permissive' o 'strict'", {}
    allow = raw.get("allow", [])
    normalized_allow: list[str] = []
    if allow is not None:
        if not isinstance(allow, list):
            return False, "egress_policy.allow debe ser una lista", {}
        for entry in allow:
            if not isinstance(entry, str):
                return False, "cada entrada de allow debe ser texto (host, sufijo .dominio o IP)", {}
            e = entry.strip().lower()
            if not e:
                continue
            if e == "*":
                return False, "el comodín '*' no está permitido en allow (sería allow-all)", {}
            normalized_allow.append(e)
    ap_raw = raw.get("allow_private", False)
    allow_private = bool(ap_raw)
    policy = {"mode": mode}
    if mode == "strict":
        policy["allow"] = normalized_allow
        policy["allow_private"] = allow_private
    return True, "", policy


def _request_id(handler) -> str:
    current = getattr(handler, "_request_id", "")
    if current:
        return current
    supplied = (handler.headers.get("X-Request-ID") or "").strip()
    if supplied and len(supplied) <= 80 and all(ch.isalnum() or ch in "-_." for ch in supplied):
        current = supplied
    else:
        current = os.urandom(12).hex()
    handler._request_id = current
    return current


def _log_event(event: str, **fields) -> None:
    record = {"ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "event": event, **fields}
    print(json.dumps(record, ensure_ascii=False, separators=(",", ":")), flush=True)


def _send_json(handler, obj, code=200):
    body = json.dumps(obj, ensure_ascii=False, indent=2).encode("utf-8")
    handler.send_response(code)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("X-Content-Type-Options", "nosniff")
    handler.send_header("X-Frame-Options", "DENY")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("X-Request-ID", _request_id(handler))
    api_version = getattr(handler, "_api_version", "")
    if api_version:
        handler.send_header("X-API-Version", api_version)
        if api_version == "v1":
            handler.send_header("Deprecation", "true")
            handler.send_header("Sunset", "Thu, 31 Dec 2027 23:59:59 GMT")
    # CSP: only same-origin resources; blocks injected third-party scripts (XSS)
    handler.send_header(
        "Content-Security-Policy",
        "default-src 'self'; img-src 'self' data: https://tile.openstreetmap.org; style-src 'self' 'unsafe-inline'; "
        "script-src 'self'; connect-src 'self'; frame-ancestors 'none'",
    )
    for c in getattr(handler, "_set_cookies", []) or []:
        handler.send_header("Set-Cookie", c)
    handler._set_cookies = []
    handler.end_headers()
    handler.wfile.write(body)


def _send_text(handler, text: str, content_type="text/plain; charset=utf-8", code=200):
    body = text.encode("utf-8")
    handler.send_response(code)
    handler.send_header("Content-Type", content_type)
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("X-Content-Type-Options", "nosniff")
    handler.send_header("X-Frame-Options", "DENY")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("X-Request-ID", _request_id(handler))
    handler.end_headers()
    handler.wfile.write(body)


def _send_file(handler, path: Path, content_type: str):
    try:
        body = path.read_bytes()
    except FileNotFoundError:
        handler.send_error(404)
        return
    handler.send_response(200)
    handler.send_header("Content-Type", content_type)
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("X-Content-Type-Options", "nosniff")
    handler.send_header("X-Frame-Options", "DENY")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("X-Request-ID", _request_id(handler))
    csp = ("default-src 'self'; img-src 'self' data: https://tile.openstreetmap.org; style-src 'self' 'unsafe-inline'; "
           "script-src 'self' 'unsafe-inline'; connect-src 'self' https://raw.githubusercontent.com https://api.github.com; "
           "frame-ancestors 'none'") if path.name in ("cloud.html", "index.html") else (
           "default-src 'self'; img-src 'self' data: https://tile.openstreetmap.org; style-src 'self' 'unsafe-inline'; "
           "script-src 'self'; connect-src 'self'; frame-ancestors 'none'")
    handler.send_header("Content-Security-Policy", csp)
    handler.end_headers()
    handler.wfile.write(body)


def _send_csv(handler, filename: str, csv_text: str):
    body = csv_text.encode("utf-8")
    handler.send_response(200)
    handler.send_header("Content-Type", "text/csv; charset=utf-8")
    handler.send_header("Content-Disposition", f'attachment; filename="{filename}"')
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("X-Content-Type-Options", "nosniff")
    handler.send_header("X-Frame-Options", "DENY")
    handler.send_header("Cache-Control", "no-store")
    handler.end_headers()
    handler.wfile.write(body)


def _send_pdf(handler, filename: str, pdf_bytes: bytes):
    handler.send_response(200)
    handler.send_header("Content-Type", "application/pdf")
    handler.send_header("Content-Disposition", f'attachment; filename="{filename}"')
    handler.send_header("Content-Length", str(len(pdf_bytes)))
    handler.send_header("X-Content-Type-Options", "nosniff")
    handler.send_header("X-Frame-Options", "DENY")
    handler.send_header("Cache-Control", "no-store")
    handler.end_headers()
    handler.wfile.write(pdf_bytes)


def _send_html(handler, html_text: str):
    body = html_text.encode("utf-8")
    handler.send_response(200)
    handler.send_header("Content-Type", "text/html; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("X-Content-Type-Options", "nosniff")
    handler.send_header("X-Frame-Options", "DENY")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header(
        "Content-Security-Policy",
        "default-src 'self'; img-src 'self' data: https://tile.openstreetmap.org; style-src 'self' 'unsafe-inline'; "
        "script-src 'self'; connect-src 'self'; frame-ancestors 'none'")
    handler.send_header("X-Request-ID", _request_id(handler))
    handler.end_headers()
    handler.wfile.write(body)


def _summary(devices: list[dict]) -> dict:
    from lucidfence.core.risk_levels import count_high_risk

    total = len(devices)
    compliant = sum(1 for d in devices if d.get("compliant") is True)
    noncompliant = sum(1 for d in devices if d.get("compliant") is False)
    outside = sum(1 for d in devices if d.get("fence_state") == "outside")
    # count_high_risk NO cuenta risk_score=None como riesgo alto NI como bajo
    # (anti falso-verde #302 / t_0de7c223).
    high_risk = count_high_risk(devices, 70)
    unknown_risk = sum(1 for d in devices if d.get("risk_score") is None)
    return {
        "total": total, "compliant": compliant, "noncompliant": noncompliant,
        "outside": outside, "high_risk": high_risk, "unknown_risk": unknown_risk,
    }


def _atomicmail_username_for_org(org) -> str:
    """Return a stable Atomic Mail username candidate for one local org."""
    raw = "".join(ch for ch in (getattr(org, "slug", "") or "lucidfence") if ch.isalnum())
    raw = (raw or "lucidfence").lower()
    suffix = (getattr(org, "id", "") or "local")[-4:].lower()
    username = f"lf{raw[:15]}{suffix}"
    if len(username) < 5:
        username = (username + "local")[:5]
    return username[:21]


def _welcome_email_text(name: str, org) -> str:
    who = (name or "equipo").strip()
    org_name = getattr(org, "name", "tu organización")
    return "\n".join([
        f"Hola {who},",
        "",
        f"Bienvenido a LucidFence para {org_name}.",
        "LucidFence corre 100% local/on-prem: no tienes que registrar nada en una nube de LucidFence.",
        "",
        "3 pasos para activar valor hoy:",
        "1) Arrancar: instala/actualiza y levanta el panel local con `brew install adrimg3196/lucidfence/lucidfence` y `lucidfence serve`.",
        "2) Geocercas: crea tu primera geocerca crítica (almacén, tienda, ruta o zona de riesgo) y asigna dispositivos piloto.",
        "3) Incidencias: abre Riesgo/Incidencias, fuerza un ciclo y revisa evidencias, severidad y acciones sugeridas antes de pasar a live.",
        "",
        "Tip: empieza con el tier gratis y un piloto de 5 dispositivos; cuando veas señal, conecta Applivery/UEM en Ajustes.",
        "",
        "Descarga gratis y docs: https://github.com/adrimg3196/lucidfence",
        "",
        "— LucidFence",
    ])


def _test_or_placeholder_email(email: str) -> bool:
    domain = (email.rsplit("@", 1)[-1] if "@" in email else "").lower()
    return domain.endswith(".test") or domain.endswith(".local") or domain in {"example.com", "example.org", "example.net"}


def _send_signup_welcome_email(email: str, name: str, org) -> dict:
    """Best-effort Atomic Mail welcome for a newly-created local tenant.

    The product remains sovereign/local: this sends from the customer's own
    local instance via Atomic Mail and never requires a LucidFence cloud signup.
    It is deliberately non-fatal: signup must succeed even if mail/network is
    unavailable. Test/placeholder domains are skipped to keep CI hermetic.
    """
    email = (email or "").strip()
    if not email or "@" not in email:
        return {"attempted": False, "sent": False, "reason": "email_invalido"}
    if _test_or_placeholder_email(email):
        return {"attempted": False, "sent": False, "reason": "destinatario_test"}
    try:
        from lucidfence.core.atomicmail_client import build_tenant_mailbox
        tdir = _tenants.data_dir(org.id)
        runtime = _tenant_runtime(tdir)
        am = runtime.get("atomicmail") or {}
        username = (am.get("username") or os.environ.get("LUCIDFENCE_WELCOME_ATOMICMAIL_USERNAME")
                    or _atomicmail_username_for_org(org)).strip()
        api_key = (am.get("api_key") or os.environ.get("LUCIDFENCE_WELCOME_ATOMICMAIL_API_KEY") or "").strip()
        wl = runtime.get("whitelabel") or {}
        inbox_domain = (wl.get("domain") or "").strip() or None
        mb = build_tenant_mailbox(tdir, username=username or None, api_key=api_key or None,
                                  inbox_domain=inbox_domain)
        subject = "[LucidFence] Bienvenido: 3 pasos para activar valor hoy"
        ok = mb.send(to=email, subject=subject, text=_welcome_email_text(name, org))
        status = {"attempted": True, "sent": bool(ok), "inbox": mb.status().get("inbox")}
        if ok:
            saved_key = mb.persist_api_key()
            if saved_key:
                new_am = dict(am)
                new_am.update({"username": username, "api_key": saved_key,
                               "digest_email_to": am.get("digest_email_to") or email})
                _save_tenant_integration(
                    tdir,
                    runtime.get("mode", "simulation"),
                    bool(runtime.get("dry_run", True)),
                    incident_webhook_url=runtime.get("incident_webhook_url", ""),
                    atomicmail=new_am,
                    whitelabel=wl if wl else None,
                )
        else:
            status["last_error"] = mb.status().get("last_error")
        return status
    except Exception as exc:  # noqa: BLE001 - welcome email must never break signup
        return {"attempted": True, "sent": False, "reason": f"{type(exc).__name__}: {exc}"}


def _read_body(handler) -> dict:
    raw = getattr(handler, "_preread_body", None)
    if raw is None:
        try:
            length = int(handler.headers.get("Content-Length", 0) or 0)
        except (ValueError, TypeError):
            return {}
        if not length:
            return {}
        if length > 1_048_576:  # 1 MiB hard cap
            return {}
        raw = handler.rfile.read(length)
    if not raw:
        return {}
    try:
        data = json.loads(raw.decode("utf-8", "replace") or "{}")
    except Exception:
        return {}
    # Contract: request bodies are JSON objects. Arrays/strings/numbers would
    # otherwise crash handlers that call body.get(...) with an AttributeError
    # and leak a 500 stack trace.
    return data if isinstance(data, dict) else {}



def _product_bundle(eng: Engine) -> dict:
    st = eng.status()
    st["stats_history"] = eng.store.stats_history(120)
    return build_product(st, eng)


# ---- rutas declarativas (SD-1 paso 1) -----------------------------------
# Rutas GET de solo lectura con el ritual estándar (sesión + org + engine +
# capability + JSON) viven en lucidfence/saas/routing.py: el handler declara
# QUÉ devuelve y QUÉ capability exige; el ritual completo queda detrás del
# seam. Las rutas con gating especial (auth, escrituras, doble llave) siguen
# en la cadena `if` de _route() hasta futuros incrementos.
# El registro es de ESTE módulo (no un global de routing): re-ejecutar
# saas_server.py (tests que lo cargan por path) parte de una tabla limpia.
_api_routes = routing.RouteRegistry()
api_route = _api_routes.route

@api_route("GET", "/api/coverage", cap="device:read")
def _api_coverage(ctx: routing.Ctx):
    """Informe de puntos ciegos (coverage gap): el negativo de la cobertura
    del tenant — solo lectura sobre estado ya existente, estrictamente
    local (ver core/coverage.py). Mismo gating que /api/cve."""
    from lucidfence.core.coverage import coverage_report
    # ?stale_after_s=N ajusta el umbral de "lost sheep" por llamada
    # (acotado 60s..30 días; fuera de rango o no numérico -> 400, no
    # silencio: un umbral ignorado daría un informe que miente).
    stale_after_s = 86400
    raw = (ctx.qs.get("stale_after_s") or [None])[0]
    if raw is not None:
        try:
            stale_after_s = int(raw)
        except ValueError:
            return {"error": "stale_after_s debe ser entero (segundos)"}, 400
        if not (60 <= stale_after_s <= 2592000):
            return {"error": "stale_after_s fuera de rango (60..2592000)"}, 400
    devices = [s.to_dict() for s in ctx.eng.store.snapshot().values()]
    return coverage_report(devices, ctx.eng.fences, stale_after_s=stale_after_s)


@api_route("GET", "/api/second-opinion", cap="device:read")
def _api_second_opinion(ctx: routing.Ctx):
    """Segunda opinión: lo que el UEM afirma vs lo que LucidFence observa.

    Solo lectura sobre estado ya existente, estrictamente local y acotado al
    tenant (ver core/second_opinion.py). Mismo gating que /api/coverage."""
    from lucidfence.core.second_opinion import (
        DEFAULT_STALE_CLAIM_AFTER_S, second_opinion_report)
    # ?stale_claim_after_s=N ajusta cuándo un check-in del UEM se considera más
    # viejo que nuestra observación. Fuera de rango -> 400, nunca silencio: un
    # umbral ignorado devolvería un informe que miente.
    stale_after_s = DEFAULT_STALE_CLAIM_AFTER_S
    raw = (ctx.qs.get("stale_claim_after_s") or [None])[0]
    if raw is not None:
        try:
            stale_after_s = int(raw)
        except ValueError:
            return {"error": "stale_claim_after_s debe ser entero (segundos)"}, 400
        if not (60 <= stale_after_s <= 2592000):
            return {"error": "stale_claim_after_s fuera de rango (60..2592000)"}, 400
    devices = [st.to_dict() for st in ctx.eng.store.snapshot().values()]
    return second_opinion_report(devices, stale_claim_after_s=stale_after_s)


@api_route("GET", "/api/fleet/federated", cap="device:read")
def _api_fleet_federated(ctx: routing.Ctx):
    """Panel único multi-UEM (backlog §12): la flota de TODOS los providers del
    tenant en una sola lista, con el origen trazado (provider + segmento) y el
    MISMO veredicto de riesgo explicable para todos.

    Solo lectura sobre estado ya existente: el riesgo es el veredicto que el
    engine ya produce por dispositivo (la misma vía que /api/risk), nunca un
    recálculo del panel. Un campo que el UEM no reportó llega como null — jamás
    se inventa ni penaliza (ver core/federated_fleet.py). Mismo gating que
    /api/coverage."""
    from lucidfence.core.federated_fleet import (build_federated_fleet,
                                                 valid_provider_filter)
    from lucidfence.core.product import _risk_from_engine
    # ?provider= filtra por UEM de origen. Un filtro que no puede ser un nombre
    # de provider -> 400, no silencio: un filtro ignorado devolvería una lista
    # que miente.
    provider = (ctx.qs.get("provider") or [None])[0]
    if provider is not None and not valid_provider_filter(provider):
        return {"error": "provider inválido (nombre de UEM: minúsculas/dígitos/_)"}, 400
    devices = [st.to_dict() for st in ctx.eng.store.snapshot().values()]
    risk_rows = _risk_from_engine(ctx.eng, devices, int(getattr(ctx.eng, "interval", 900) or 900))
    # Del registro del tenant solo viajan nombre + segmento (jamás credenciales).
    providers = [{"name": p.get("name"), "segment": p.get("segment")}
                 for p in _list_providers(_tenants.data_dir(ctx.org))]
    return build_federated_fleet(devices, risk_rows, providers, provider=provider)


@api_route("GET", "/api/device-attestation", cap="device:read")
def _api_device_attestation(ctx: routing.Ctx):
    """Sobre neutral de atestación Apple/Android/Windows.

    Solo lectura sobre DeviceState persistido: no consulta UEMs, no expone
    payloads brutos y conserva unknown como unknown (ver core/device_attestation.py).
    """
    from lucidfence.core.device_attestation import attestation_report
    devices = [st.to_dict() for st in ctx.eng.store.snapshot().values()]
    return attestation_report(devices)


@api_route("GET", "/api/least-privilege", cap="engine:config")
def _api_least_privilege(ctx: routing.Ctx):
    """Auditor de mínimo privilegio de las credenciales UEM (backlog §16): qué
    puede el token de cada adapter conectado frente a lo que el modo de
    enforcement actual necesita (ver core/least_privilege.py).

    Gating `engine:config` (más estricto que /api/coverage) a propósito: el
    informe dice en voz alta qué credenciales del tenant pueden wipear, y quien
    puede recortar el token es exactamente quien tiene esta capability.

    Del registro del tenant solo viajan nombre, scopes declarados y si hay
    credencial: la credencial NUNCA sale de disco."""
    from lucidfence.core.least_privilege import least_privilege_report
    from lucidfence.saas.providers import PROVIDER_CATALOG
    rows = []
    for p in _list_providers(_tenants.data_dir(ctx.org)):
        name = p.get("name")
        rows.append({
            "name": name,
            "scopes": p.get("scopes"),
            "configured": _masked_provider(p).get("configured"),
            "min_permission": (PROVIDER_CATALOG.get(name) or {}).get("min_permission") or None,
        })
    return least_privilege_report(rows, ctx.eng.enforcement_status())


@api_route("GET", "/api/risk", cap="device:read")
def _api_risk(ctx: routing.Ctx):
    product = _product_bundle(ctx.eng)
    return {"risk": product.get("risk", []),
            "summary": product.get("summary", {})}


@api_route("GET", "/api/cve", cap="device:read")
def _api_cve(ctx: routing.Ctx):
    devices = [
        {"device_id": s.device_id, "name": s.name, "apps": s.apps}
        for s in ctx.eng.store.snapshot().values()
    ]
    summary = ctx.eng._cve_summary()
    if not (summary.get("vulnerable_apps") or 0):
        # No real signal (local dev / offline / empty fleet): broadcast
        # demo fallback aligned with cloud publisher behavior.
        summary = dict(summary)
        summary.update(cloud_publisher._demo_cve_summary(summary, total=len(devices)))
    else:
        summary = dict(summary)
        try:
            from lucidfence.core import cve as _cve
            nvd_keys = [k for k, v in _cve._FEED.items() if v]
            summary["demo"] = False
            summary["source"] = "engine-cve-feed" if nvd_keys else "local-db"
        except Exception:
            summary["source"] = "local-db"
    return {"cve_summary": summary, "devices": devices}


@api_route("GET", "/api/pois", cap="device:read")
def _api_pois(ctx: routing.Ctx):
    lat = ctx.qs.get("lat", [None])[0]
    lng = ctx.qs.get("lng", [None])[0]
    if lat is not None and lng is not None:
        try:
            lat_f, lng_f = float(lat), float(lng)
            radius_m = float(ctx.qs.get("radius_m", ["1000"])[0])
            limit = min(int(ctx.qs.get("limit", ["5"])[0]), 100)
        except (TypeError, ValueError):
            return {"error": "lat/lng/radius_m/limit inválidos"}, 400
        nearby = _poi_service.search_nearby(lat_f, lng_f, radius_m, limit=limit)
        return [dict(p.to_dict(), distance_m=round(d, 1)) for p, d in nearby]
    return [p.to_dict() for p in _poi_service.all()]


@api_route("GET", "/api/incidents/analytics", cap="incident:read")
def _api_incidents_analytics(ctx: routing.Ctx):
    return {"analytics": ctx.eng.incidents.analytics()}


@api_route("GET", "/api/fences", cap="fence:read")
def _api_fences_list(ctx: routing.Ctx):
    return {"fences": ctx.eng.status().get("fences", [])}


class LucidFenceHTTPServer(ThreadingHTTPServer):
    """HTTP server whose local bind never depends on reverse DNS."""

    def server_bind(self) -> None:
        # http.server.HTTPServer.server_bind calls socket.getfqdn(host). On
        # macOS that reverse lookup can block indefinitely even for 127.0.0.1.
        # TCPServer performs the real socket bind without any DNS dependency.
        TCPServer.server_bind(self)
        host, port = self.server_address[:2]
        self.server_name = str(host)
        self.server_port = int(port)


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"

    def log_message(self, fmt, *args):
        # Solo se redactan los args de texto: send_error() pasa el código como
        # int con formato %d y convertirlo a str rompería el logging (500s).
        safe_args = tuple(_redact_access_path(a) if isinstance(a, str) else a
                          for a in args)
        super().log_message(fmt, *safe_args)

    def do_GET(self):
        if not _host_allowed(self):
            self.send_error(400, "bad host")
            return
        ok, retry_after, _ = _rate_limit_check(self)
        if not ok:
            return _send_rate_limited(self, retry_after)
        try:
            self._route()
        except Exception as e:
            _log_event("route_error", request_id=_request_id(self), method=self.command,
                       route=urlparse(self.path).path, error_type=type(e).__name__)
            try:
                _send_json(self, {"error": "server_error"}, 500)
            except Exception:
                pass

    def do_POST(self):
        if not _host_allowed(self):
            self.send_error(400, "bad host")
            return
        ok, retry_after, _ = _rate_limit_check(self)
        if not ok:
            return _send_rate_limited(self, retry_after)
        try:
            # Pre-read the full body so the socket is left clean under HTTP/1.0
            # (otherwise the connection closes with unread bytes and the client
            # sees "HTTP/0.9 when not allowed"). _read_body() reuses it.
            raw_length = self.headers.get("Content-Length", "0") or "0"
            try:
                length = int(raw_length)
            except (TypeError, ValueError):
                return _send_json(self, {"error": "content_length invalido"}, 400)
            if length < 0 or length > MAX_REQUEST_BODY:
                return _send_json(self, {"error": "payload demasiado grande", "max_bytes": MAX_REQUEST_BODY}, 413)
            if length > 0:
                self._preread_body = self.rfile.read(length)
            else:
                self._preread_body = b""
            self._route()
        except Exception as e:
            _log_event("route_error", request_id=_request_id(self), method=self.command,
                       route=urlparse(self.path).path, error_type=type(e).__name__)
            try:
                _send_json(self, {"error": "server_error"}, 500)
            except Exception:
                pass

    def do_DELETE(self):
        if not _host_allowed(self):
            self.send_error(400, "bad host")
            return
        ok, retry_after, _ = _rate_limit_check(self)
        if not ok:
            return _send_rate_limited(self, retry_after)
        try:
            self._route()
        except Exception as e:
            _log_event("route_error", request_id=_request_id(self), method=self.command,
                       route=urlparse(self.path).path, error_type=type(e).__name__)
            try:
                _send_json(self, {"error": "server_error"}, 500)
            except Exception:
                pass

    def do_PATCH(self):
        # Reutiliza la misma logica que POST (el handler HTTP/1.0 no tiene
        # do_PATCH por defecto). Las rutas que lo necesitan comprueban
        # self.command == "PATCH" dentro de _route().
        self.do_POST()

    def _route(self):
        parsed = urlparse(self.path)
        route = parsed.path
        qs = parse_qs(parsed.query)
        method = self.command
        for version in ("v2", "v1"):
            prefix = f"/api/{version}"
            if route == prefix or route.startswith(prefix + "/"):
                self._api_version = version
                suffix = route[len(prefix):]
                route = "/api" + (suffix or "/")
                break
        with _metrics_lock:
            _request_counts[method] = _request_counts.get(method, 0) + 1

        if route == "/metrics" and method == "GET":
            with _metrics_lock:
                counts = dict(_request_counts)
            lines = [
                "# HELP lucidfence_http_requests_total HTTP requests handled by method.",
                "# TYPE lucidfence_http_requests_total counter",
            ]
            for verb, count in sorted(counts.items()):
                lines.append(f'lucidfence_http_requests_total{{method="{verb}"}} {count}')
            lines.extend([
                "# TYPE lucidfence_tenants gauge",
                f"lucidfence_tenants {len(_tenants.all())}",
                "# TYPE lucidfence_engines gauge",
                f"lucidfence_engines {len(_engines)}",
                "",
            ])
            return _send_text(self, "\n".join(lines), "text/plain; version=0.0.4; charset=utf-8")

        # static
        if route in ("/", "/app", "/app/", "/dashboard", "/dashboard.html"):
            _send_file(self, STATIC / "dashboard.html", "text/html; charset=utf-8")
            return
        if route in ("/about", "/index.html", "/landing", "/landing.html"):
            _send_file(self, STATIC / "index.html", "text/html; charset=utf-8")
            return
        if route in ("/cloud", "/cloud.html"):
            _send_file(self, STATIC / "cloud.html", "text/html; charset=utf-8")
            return
        if route.startswith("/static/"):
            rel = route[len("/static/"):]
            p = (STATIC / rel).resolve()
            if p.is_relative_to(STATIC):
                ct = mimetypes.guess_type(str(p))[0] or "application/octet-stream"
                if p.suffix == ".js":
                    ct = "application/javascript"
                _send_file(self, p, ct)
            else:
                self.send_error(404)
            return
        # Los assets del sistema de diseño se referencian RELATIVOS en el HTML
        # (`href="design.css"`), porque cloud.html tiene que funcionar también
        # abierto como fichero — el usuario se descarga el tarball y lo abre.
        # Con ruta absoluta a raíz, `file:///static/design.css` no existe.
        # A cambio, las páginas que servimos FUERA de /static/ (`/`, `/app/`,
        # `/dashboard`, `/cloud`, `/about`...) resuelven el asset contra su
        # propia ruta, así que aquí lo atendemos venga de donde venga.
        if method == "GET":
            tail = route.rsplit("/", 1)[-1]
            asset = None
            if tail == "design.css":
                asset = STATIC / "design.css"
            elif tail.endswith(".woff2") and "/fonts/" in route:
                asset = (STATIC / "fonts" / tail).resolve()
                if not asset.is_relative_to((STATIC / "fonts").resolve()):
                    asset = None
            if asset is not None and asset.is_file():
                ct = mimetypes.guess_type(str(asset))[0] or "application/octet-stream"
                _send_file(self, asset, ct)
                return

        if route == "/favicon.ico" and method == "GET":
            self.send_response(204)
            self.send_header("Cache-Control", "public, max-age=86400")
            self.end_headers()
            return
        if route == "/api/openapi.json" and method == "GET":
            try:
                schema = json.loads((ROOT / "docs" / "architecture" / "openapi.json").read_text(encoding="utf-8"))
                return _send_json(self, schema)
            except (OSError, json.JSONDecodeError):
                return _send_json(self, {"error": "openapi no disponible"}, 503)

        # ---- auth ----
        if route == "/api/auth/sso/providers" and method == "GET":
            return _send_json(self, {"providers": [p.public_dict() for p in _oidc_providers.values()]})
        if route.startswith("/api/auth/sso/") and route.endswith("/start") and method == "GET":
            provider_name = route[len("/api/auth/sso/"):-len("/start")]
            return self._oidc_start(provider_name, qs)
        if route.startswith("/api/auth/sso/") and route.endswith("/callback") and method == "GET":
            provider_name = route[len("/api/auth/sso/"):-len("/callback")]
            return self._oidc_callback(provider_name, parsed.query)
        if route == "/api/auth/signup" and method == "POST":
            return self._signup()
        if route == "/api/auth/demo" and method == "POST":
            return self._demo_login()
        if route == "/api/auth/login" and method == "POST":
            return self._login()
        if route == "/api/auth/logout" and method == "POST":
            return self._logout()
        if route == "/api/auth/me" and method == "GET":
            user = user_from_request(self)
            if not user:
                return _send_json(self, {"error": "no autenticado"}, 401)
            return _send_json(self, {"user": user,
                                     "orgs": [o.to_dict() for o in _tenants.list_for_user(user["id"])]})

        # ---- Healthcheck sin auth (para monitoreo externo / scripts/start_all.sh) ----
        if route in ("/api/health", "/api/healthz") and method == "GET":
            return _send_json(self, {"status": "ok", "service": "lucidfence",
                                     "desktop_nonce": os.environ.get("LUCIDFENCE_DESKTOP_NONCE", ""),
                                     "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
        if route == "/api/readyz" and method == "GET":
            return _send_json(self, {"ready": True, "service": "lucidfence",
                                     "tenants_loaded": len(_tenants.all()),
                                     "cluster_mode": os.environ.get("LUCIDFENCE_CLUSTER_MODE", "single"),
                                     "leader": bool(_cluster_lease and _cluster_lease.acquired) if os.environ.get("LUCIDFENCE_CLUSTER_MODE") == "active-passive" else True,
                                     "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})

        # Validate the location_source mapping against the live UEM/MDM API.
        # Works for any vendor configured via the generic HTTP source.
        if route == "/api/config/validate" and method == "GET":
            try:
                from lucidfence.core.config_validator import validate_config
                return _send_json(self, validate_config(str(CONFIG_FILE)))
            except Exception as e:  # noqa: BLE001 — surface as JSON, never 500 hygiene
                return _send_json(self, {"ok": False, "error": f"{type(e).__name__}: {e}"}, 200)


        # ---- Incoming SOAR webhook (headless automation, HMAC-authenticated) ----
        # External SOAR tools cannot hold a browser session cookie. This endpoint
        # is intentionally before `require(self)`, but every request must carry a
        # tenant-scoped HMAC signature over the exact raw body + timestamp.
        if route.startswith("/api/soar/webhook/") and method == "POST":
            org_id = route[len("/api/soar/webhook/"):].strip("/")
            if not org_id or _tenants.get(org_id) is None:
                return _send_json(self, {"ok": False, "error": "tenant no encontrado"}, 404)
            tdir = _tenants.data_dir(org_id)
            runtime = _tenant_runtime(tdir)
            secret = (runtime.get("soar_webhook_secret")
                      or os.environ.get("LUCIDFENCE_SOAR_WEBHOOK_SECRET") or "")
            raw = getattr(self, "_preread_body", b"") or b""
            ok, reason = _verify_soar_webhook_hmac(raw, self.headers, secret)
            if not ok:
                return _send_json(self, {"ok": False, "error": reason}, 401)
            body = _read_body(self)
            device_id = (body.get("device_id") or body.get("deviceId") or "").strip()
            action = (body.get("action") or "").strip().lower()
            params = body.get("params")
            if not isinstance(params, dict):
                params = {}
            if not device_id or not action:
                return _send_json(self, {"ok": False, "error": "device_id y action son obligatorios"}, 400)
            eng = engine_for(org_id)
            dev = eng.store.get(device_id)
            if dev is None:
                return _send_json(self, {"ok": False, "error": "dispositivo no encontrado"}, 404)
            result = eng.run_command(dev, action, params, operator="soar:webhook")
            result["soar_webhook"] = True
            return _send_json(self, {"ok": bool(result.get("ok") or result.get("delegated") or result.get("dry_run")),
                                     "result": result})

        # ---- Local OpenAI-compatible gateway (headless clients / MCP) ----
        if route == "/v1/chat/completions" and method == "POST":
            if not _gateway_allowed(self):
                return _send_json(self, {"error": {"message": "gateway bearer token requerido", "type": "authentication_error"}}, 401)
            org_id = _gateway_tenant(self)
            if not org_id:
                return _send_json(self, {"error": {"message": "no hay proveedor AI configurado", "type": "provider_not_configured"}}, 503)
            body = _read_body(self)
            messages = body.get("messages") if isinstance(body, dict) else None
            if not isinstance(messages, list) or not messages:
                return _send_json(self, {"error": {"message": "messages debe ser una lista no vacía", "type": "invalid_request_error"}}, 400)
            result = ai_provider.chat(_tenants.data_dir(org_id), messages, body)
            if not result.get("ok"):
                return _send_json(self, {"error": {"message": result.get("error", "provider error"), "type": "provider_error"}}, int(result.get("status") or 502))
            return _send_json(self, result["response"])

        # everything else needs a session
        guarded = require(self)
        if guarded is None:
            return
        user, org = guarded

        # Tenant API keys: high-entropy bearer tokens, shown once, hashed at rest.
        role = user["org_roles"].get(org)
        # Operational planning data is authenticated. Mutation is restricted to
        # an owner browser session so an automation key cannot rewrite the repo.
        if route == "/api/roadmap" and method == "GET":
            try:
                from lucidfence.core import roadmap_tooling as _rm
                data = _rm.load_roadmap()
                if not data:
                    return _send_json(self, {"error": "roadmap.json no encontrado"}, 404)
                return _send_json(self, _rm.get_api_response(data))
            except Exception:
                return _send_json(self, {"error": "roadmap no disponible"}, 404)
        if route == "/api/roadmap" and method == "PATCH":
            if role != "owner" or user.get("auth_type") == "api_key":
                return _send_json(self, {"error": "solo owner con sesion"}, 403)
            try:
                from lucidfence.core import roadmap_tooling as _rm
                data = _rm.load_roadmap()
                if not data:
                    return _send_json(self, {"error": "roadmap.json no encontrado"}, 404)
                code, response = _rm.patch_api(data, _read_body(self))
                append_audit(_tenants.data_dir(org), {"event": "roadmap.updated", "actor": user.get("id")})
                return _send_json(self, response, code)
            except Exception:
                return _send_json(self, {"error": "roadmap update invalida"}, 400)
        if route == "/api/loop/metrics" and method == "GET":
            try:
                import loop_improve as _loop
                return _send_json(self, _loop.loop_metrics())
            except Exception:
                return _send_json(self, {"error": "metricas de loop no disponibles"}, 503)
        if route == "/api/api-keys" and method == "GET":
            if role != "owner":
                return _send_json(self, {"error": "solo owner"}, 403)
            return _send_json(self, {"keys": _api_keys.list_for_org(org)})
        if route == "/api/api-keys" and method == "POST":
            if role != "owner" or user.get("auth_type") == "api_key":
                return _send_json(self, {"error": "solo owner con sesion"}, 403)
            body = _read_body(self)
            try:
                token, record = _api_keys.create(org, body.get("name", "automation"), body.get("role", "operator"))
            except ValueError as exc:
                return _send_json(self, {"error": str(exc)}, 400)
            append_audit(_tenants.data_dir(org), {"event": "api_key.created", "actor": user.get("id"), "key_id": record["id"], "role": record["role"]})
            return _send_json(self, {"ok": True, "key": token, "record": record}, 201)
        if route.startswith("/api/api-keys/") and method == "DELETE":
            if role != "owner" or user.get("auth_type") == "api_key":
                return _send_json(self, {"error": "solo owner con sesion"}, 403)
            key_id = route[len("/api/api-keys/"):].strip("/")
            if not _api_keys.revoke(org, key_id):
                return _send_json(self, {"error": "api key no encontrada"}, 404)
            append_audit(_tenants.data_dir(org), {"event": "api_key.revoked", "actor": user.get("id"), "key_id": key_id})
            return _send_json(self, {"ok": True})
        if route == "/api/audit" and method == "GET":
            if role not in ("owner", "admin", "viewer", "auditor"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            audit_path = _tenants.data_dir(org) / "audit.jsonl"
            events = []
            try:
                for line in audit_path.read_text(encoding="utf-8").splitlines()[-500:]:
                    item = json.loads(line)
                    if isinstance(item, dict):
                        events.append(item)
            except (OSError, json.JSONDecodeError):
                events = []
            cef = [f"CEF:0|LucidFence|Local|1.3|{e.get('event','event')}|{e.get('event','event')}|5|rt={e.get('ts','')} act={e.get('actor','')} cs1={e.get('hash','')} cs1Label=chainHash" for e in events]
            return _send_json(self, {"events": events, "cef": cef, "integrity": verify_audit(_tenants.data_dir(org))})

        # engine is per-org; build/lookup it once for the whole request
        eng = engine_for(org)

        # Patrón nuevo (SD-1 paso 1): las rutas GET de solo lectura con el
        # ritual estándar viven en el registro declarativo de
        # lucidfence/saas/routing.py, no en esta cadena `if`.
        ctx = routing.Ctx(http=self, user=user, org=org, eng=eng, qs=qs)
        if _api_routes.dispatch(method, route, ctx,
                                send=lambda obj, code=200: _send_json(self, obj, code)):
            return

        if route == "/api/evidence/export" and method == "GET":
            # Informe de evidencia con cadena de hashes verificable offline
            # (ver core/evidence_export.py). Mismo círculo de visibilidad que
            # /api/audit: el rol auditor existe precisamente para esto.
            if role not in ("owner", "admin", "viewer", "auditor"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            from lucidfence.core.evidence_export import build_evidence_report
            devices = [s.to_dict() for s in eng.store.snapshot().values()]
            apps_total = sum(len(d.get("apps") or []) for d in devices)
            report = build_evidence_report(
                org=org,
                devices=devices,
                events=eng.store.recent_events(limit=2000),
                actions=eng.store.recent_actions(limit=2000),
                cve_summary={"apps_total": apps_total},
                audit_integrity=verify_audit(_tenants.data_dir(org)),
                since=qs.get("from", [None])[0],
                until=qs.get("to", [None])[0],
            )
            append_audit(_tenants.data_dir(org), {
                "event": "evidence.exported", "actor": user.get("id"),
                "period": report["period"], "records": len(report["records"]),
                "chain_head": report["chain_head"],
            })
            return _send_json(self, report)

        # GET /api/coverage migrado al registro declarativo (_api_routes, patrón SD-1).

        # Governed autonomous-company control plane. State is tenant-local and
        # no route here executes a device command: approved operational work is
        # handed back to the existing audited UEM action flow.
        if route == "/api/company" and method == "GET":
            if not AuthStore.can(role, "company:read"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            return _send_json(self, CompanyControlPlane(_tenants.data_dir(org)).snapshot())
        if route == "/api/company/goals" and method == "POST":
            if not AuthStore.can(role, "company:write") or user.get("auth_type") == "api_key":
                return _send_json(self, {"error": "requiere owner/admin con sesion"}, 403)
            try:
                goal = CompanyControlPlane(_tenants.data_dir(org)).create_goal(_read_body(self), actor=user["id"])
            except ValueError as exc:
                return _send_json(self, {"error": str(exc)}, 400)
            append_audit(_tenants.data_dir(org), {"event": "company.goal.created", "actor": user["id"], "goal_id": goal["id"]})
            return _send_json(self, goal, 201)
        if route == "/api/company/cycle" and method == "POST":
            if not AuthStore.can(role, "company:run"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            try:
                result = CompanyControlPlane(_tenants.data_dir(org)).run_cycle(_company_context(eng), actor=user["id"])
            except RuntimeError as exc:
                return _send_json(self, {"error": str(exc)}, 409)
            except ValueError as exc:
                return _send_json(self, {"error": str(exc)}, 400)
            append_audit(_tenants.data_dir(org), {"event": "company.cycle.completed", "actor": user["id"], "cycle": result["cycle"], "goal_id": result["goal_id"], "tasks": len(result["created_tasks"])})
            return _send_json(self, result)
        if route in {"/api/company/pause", "/api/company/resume"} and method == "POST":
            if not AuthStore.can(role, "company:write") or user.get("auth_type") == "api_key":
                return _send_json(self, {"error": "requiere owner/admin con sesion"}, 403)
            plane = CompanyControlPlane(_tenants.data_dir(org)); body = _read_body(self)
            try:
                result = plane.pause(body.get("reason") or "operator pause", user["id"]) if route.endswith("/pause") else plane.resume(user["id"])
            except ValueError as exc:
                return _send_json(self, {"error": str(exc)}, 400)
            append_audit(_tenants.data_dir(org), {"event": "company.paused" if result["paused"] else "company.resumed", "actor": user["id"]})
            return _send_json(self, result)
        if route.startswith("/api/company/tasks/") and method == "POST":
            if not AuthStore.can(role, "company:approve") or user.get("auth_type") == "api_key":
                return _send_json(self, {"error": "requiere owner/admin con sesion"}, 403)
            suffix = route[len("/api/company/tasks/"):].strip("/").split("/")
            if len(suffix) != 2 or suffix[1] not in {"approve", "reject"}:
                return _send_json(self, {"error": "ruta no valida"}, 404)
            task_id, action = suffix; body = _read_body(self)
            try:
                plane = CompanyControlPlane(_tenants.data_dir(org))
                task = plane.approve_task(task_id, user["id"], body.get("reason") or "reviewed") if action == "approve" else plane.reject_task(task_id, user["id"], body.get("reason") or "rejected")
            except KeyError:
                return _send_json(self, {"error": "tarea no encontrada"}, 404)
            except ValueError as exc:
                return _send_json(self, {"error": str(exc)}, 409)
            append_audit(_tenants.data_dir(org), {"event": f"company.task.{action}d", "actor": user["id"], "task_id": task_id, "risk": task.get("risk")})
            return _send_json(self, task)

        # GET /api/fences migrado al registro declarativo (_api_routes, patrón SD-1).
        if route == "/api/fences" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "fence:write"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            try:
                fence = eng.add_fence(_read_body(self))
            except ValueError as exc:
                return _send_json(self, {"error": str(exc)}, 400)
            rows = eng.status().get("fences", [])
            created = next((f for f in rows if f.get("id") == fence.id), None)
            return _send_json(self, {"ok": True, "fence": created, "fences": rows})
        if route.startswith("/api/fences/") and method == "DELETE":
            if not AuthStore.can(user["org_roles"].get(org), "fence:delete"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            fence_id = route[len("/api/fences/"):]
            if not eng.delete_fence(fence_id):
                return _send_json(self, {"error": "geovalla no encontrada"}, 404)
            return _send_json(self, {"ok": True, "fences": eng.status().get("fences", [])})

        # routes (route:read to list; route:write to create; route:delete to delete)
        if route == "/api/routes" and method == "GET":
            if not AuthStore.can(user["org_roles"].get(org), "route:read"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            return _send_json(self, {"routes": [r.to_dict() for r in eng.routes]})
        if route == "/api/routes" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "route:write"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self)
            try:
                eng.add_route(body)
            except ValueError as e:
                return _send_json(self, {"error": str(e)}, 400)
            return _send_json(self, {"ok": True, "routes": [r.to_dict() for r in eng.routes]})
        if route.startswith("/api/routes/") and route.endswith("/delete") and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "route:delete"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            rid = route[len("/api/routes/"):-len("/delete")]
            eng.delete_route(rid)
            return _send_json(self, {"ok": True, "routes": [r.to_dict() for r in eng.routes]})

        # --- workflows (workflow:read to list; workflow:write to apply/create/delete) ---
        if route == "/api/workflows" and method == "GET":
            if not AuthStore.can(user["org_roles"].get(org), "workflow:read"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            return _send_json(self, {
                "templates": WF.TEMPLATES,
                "triggers": WF.trigger_options(),
                "actions": WF.action_options(),
                "active": eng.active_workflows(),
            })
        if route == "/api/policies/replay" and method == "POST":
            # Simulador what-if: evalúa una policy CANDIDATA contra el trail
            # histórico del tenant. Solo lectura — jamás ejecuta acciones —
            # así que basta la capability de lectura de workflows.
            if not AuthStore.can(user["org_roles"].get(org), "workflow:read"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self)
            candidate = body.get("policy") if isinstance(body, dict) else None
            if not isinstance(candidate, dict) or not candidate.get("when"):
                return _send_json(self, {"error": "policy con 'when' es obligatoria"}, 400)
            from lucidfence.core.policy_replay import load_trail_points, replay_policy
            try:
                limit = min(int(body.get("limit", 5000)), 20000)
            except (TypeError, ValueError):
                limit = 5000
            points = load_trail_points(eng.store.trails_path, limit=limit)
            states = {d_id: s.to_dict() for d_id, s in eng.store.snapshot().items()}
            result = replay_policy(
                candidate, points,
                fences=eng.fences if body.get("recompute_fences") else None,
                device_states=states,
                risk_engine=eng.risk,
                risk_ctx={"shift_zones": eng._ctx_shift_zones(),
                          "zone_risk": eng._ctx_zone_risk()},
            )
            return _send_json(self, result)

        if route == "/api/workflows/apply" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "workflow:write"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self)
            try:
                pol = WF.build_policy_from_template(
                    body.get("template_id"), body.get("device_ids"))
            except ValueError as e:
                return _send_json(self, {"error": str(e)}, 400)
            eng.add_policy(pol)
            return _send_json(self, {"ok": True, "policy": pol,
                                   "active": eng.active_workflows()})
        if route == "/api/workflows/custom" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "workflow:write"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self)
            try:
                pol = WF.build_custom_policy(body)
            except ValueError as e:
                return _send_json(self, {"error": str(e)}, 400)
            eng.add_policy(pol)
            return _send_json(self, {"ok": True, "policy": pol,
                                   "active": eng.active_workflows()})
        if route.startswith("/api/workflows/") and route.endswith("/delete") and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "workflow:write"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            pid = route[len("/api/workflows/"):-len("/delete")]
            eng.delete_policy(pid)
            return _send_json(self, {"ok": True, "active": eng.active_workflows()})

        if route == "/api/devices" and method == "GET":
            states = list(eng.store.snapshot().values())
            st = qs.get("state", [None])[0]
            if st:
                states = [s for s in states if s.fence_state == st]
            return _send_json(self, [s.to_dict() for s in states])

        # GET /api/pois (exacto) migrado al registro declarativo (_api_routes, patrón SD-1).
        if route.startswith("/api/pois/") and method == "GET":
            poi = _poi_service.get_poi(route[len("/api/pois/"):])
            if poi is None:
                return _send_json(self, {"error": "POI no encontrado"}, 404)
            return _send_json(self, poi.to_dict())

        if route == "/api/org" and method == "GET":
            o = _tenants.get(org)
            return _send_json(self, {"org": o.to_dict(), "plan": FREE_PLAN,
                                     "role": user["org_roles"].get(org)})

        if route == "/api/org" and method == "DELETE":
            # Borrar la organización es destructivo y owner-only. La capability
            # 'org:delete' ya está modelada en ROLE_CAPS['owner']; aquí la
            # enforcemos y además exigimos sesión (jamás una api_key, igual que
            # el resto de operaciones destructivas de owner).
            if not AuthStore.can(user["org_roles"].get(org), "org:delete") \
                    or user.get("auth_type") == "api_key":
                return _send_json(self, {
                    "error": "solo un propietario con sesión puede eliminar la organización",
                    "capability": "org:delete"}, 403)
            # Guardarraíl del último propietario (ZERO-BACKLOG #70): una org
            # nunca puede quedar sin owner, y el único owner no puede borrarla
            # (se quedaría huérfana e inaccesible para facturación/gestión).
            if _auth.count_org_owners(org) <= 1:
                return _send_json(self, {
                    "error": "no se puede eliminar la organización siendo su único propietario; "
                             "transfiere la propiedad o dala de baja primero",
                    "capability": "org:delete"}, 400)
            # Estrictamente tenant-local: solo la org activa del usuario.
            tdir = _tenants.data_dir(org)
            append_audit(tdir, {"event": "org.deleted", "actor": user.get("id"),
                                "org_id": org})
            try:
                with _engines_lock:
                    old = _engines.pop(org, None)
                    if old is not None:
                        try:
                            old.stop()
                        except Exception:
                            pass
                removed = _tenants.delete(org)
            except Exception as exc:  # robustness: never 500 on destructive op
                return _send_json(self, {"ok": False,
                                         "error": f"org_delete_error: {type(exc).__name__}: {exc}"})
            if not removed:
                return _send_json(self, {"ok": False, "error": "org no encontrada"}, 404)
            # Invalida la cookie de org activa para que el cliente no quede
            # apuntando a un tenant ya inexistente.
            _clear_cookie(self, COOKIE_ORG)
            return _send_json(self, {"ok": True, "org_id": org,
                                     "destroyed_session_org": True})

        if route.startswith("/api/orgs/") and route.endswith("/switch") and method == "POST":
            target = route[len("/api/orgs/"):-len("/switch")]
            if target not in user["org_roles"]:
                return _send_json(self, {"error": "no perteneces a esa org"}, 403)
            _set_cookie(self, COOKIE_ORG, target)
            return _send_json(self, {"ok": True, "org": target})

        if route == "/api/run-once" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "engine:run"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            try:
                stats = eng.run_once()
            except Exception as exc:  # robustness: never 500 the UI on a flaky cycle
                return _send_json(self, {"ok": False, "error": f"cycle_error: {type(exc).__name__}: {exc}"})
            return _send_json(self, {"ok": True, "stats": stats})
        if route == "/api/status" and method == "GET":
            raw = eng.status()
            st = raw.get("stats", {}) or {}
            # Derive live device counts from the actual state store so the
            # dashboard reflects devices even before the first auto-cycle.
            snap = list(eng.store.snapshot().values())
            device_count = len(snap)
            inside_count = sum(1 for s in snap if s.fence_state == "inside")
            outside_count = sum(1 for s in snap if s.fence_state == "outside")
            unknown_count = sum(1 for s in snap if s.fence_state == "unknown")
            noncompliant = sum(1 for s in snap if s.compliant is False)
            # Return the full engine status (devices, trails, events, actions,
            # stats_history, fences, routes) — the SPA consumes all of it.
            raw.update({
                "device_count": device_count,
                "inside_count": inside_count,
                "outside_count": outside_count,
                "unknown_count": unknown_count,
                "noncompliant": noncompliant,
                "events_this_cycle": st.get("events_this_cycle", 0),
                "actions_this_cycle": st.get("actions_this_cycle", 0),
                "integration_error": st.get("integration_error"),
                "last_cycle_at": st.get("ts") or eng.last_run,
                "cycle_period_s": eng.interval,
            })
            return _send_json(self, raw)
        if route.startswith("/api/devices/") and method == "GET":
            dev_id = route[len("/api/devices/"):]
            d = eng.store.get(dev_id)
            if not d:
                return _send_json(self, {"error": "not found"}, 404)
            return _send_json(self, {"device": d.to_dict(),
                                     "trail": eng.store.trail(dev_id, 200),
                                     "events": [e for e in eng.store.recent_events(200) if e.get("device_id") == dev_id][-20:],
                                     "actions": [a for a in eng.store.recent_actions(200) if a.get("device_id") == dev_id][-20:]})

        # --- on-demand remote command (MDM/UEM action) ---------------------
        if route.startswith("/api/devices/") and route.endswith("/command") and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "device:action"):
                return _send_json(self, {"error": "sin permiso para enviar comandos"}, 403)
            dev_id = route[len("/api/devices/"):-len("/command")]
            dev = eng.store.get(dev_id)
            if not dev:
                return _send_json(self, {"error": "dispositivo no encontrado"}, 404)
            body = _read_body(self)
            action = (body.get("action") or "").strip().lower()
            if action not in VALID_ACTIONS:
                return _send_json(self, {"error": "accion no valida",
                                         "valid": sorted(VALID_ACTIONS)}, 400)
            params = dict(body.get("params") or {})
            # operator-initiated command: respect destructive cooldown but never
            # silently drop a manual command. Record who/why for the audit log.
            operator = (user.get("email") or user.get("name") or "operator")
            result = eng.run_command(dev, action, params, operator=operator)
            return _send_json(self, result)

        # incident operations: persistent triage state over derived risk incidents
        if route.startswith("/api/incidents/") and route.endswith("/transition") and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "incident:write"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            incident_id = route[len("/api/incidents/"):-len("/transition")]
            # Materialize current derived incidents before applying the transition.
            _product_bundle(eng)
            body = _read_body(self)
            try:
                incident = eng.incidents.transition(
                    incident_id,
                    body.get("status", ""),
                    actor=user["id"],
                    assignee=body.get("assignee"),
                    note=body.get("note", ""),
                )
            except KeyError:
                return _send_json(self, {"error": "incidente no encontrado"}, 404)
            except ValueError as exc:
                return _send_json(self, {"error": str(exc)}, 400)
            return _send_json(self, {"ok": True, "incident": incident})

        # product intelligence bundle (read-only, local) — alimenta la vista ROI
        if route == "/api/product" and method == "GET":
            return _send_json(self, _product_bundle(eng))

        # product intelligence (/api/risk, /api/cve y /api/incidents/analytics
        # migrados al registro declarativo _api_routes, patrón SD-1)
        if route in ("/api/incidents", "/api/incidents/export",
                     "/api/policies", "/api/analytics", "/api/activation",
                     "/api/compliance", "/api/report", "/api/soar"):
            return self._product(route, eng, user, org, method, qs)

        # --- Playbooks SOAR del tenant (REQ §5): editor desde UI, sin código) ---
        if route in ("/api/soar/playbooks", "/api/soar/playbook") and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self)
            store = getattr(eng, "soar_store", None)
            if store is None:
                return _send_json(self, {"error": "engine sin playbook store"}, 500)
            try:
                pb = store.upsert(body)
            except ValueError as exc:
                return _send_json(self, {"ok": False, "error": f"validacion: {exc}"}, 400)
            tdir = _tenants.data_dir(org)
            append_audit(tdir, {"event": "soar.playbook.created", "actor": user.get("id"), "playbook": pb.id})
            reload_engine(org)
            return _send_json(self, {"ok": True, "playbook": {"id": pb.id, "name": pb.name, "enabled": pb.enabled, "severity_min": pb.severity_min, "condition": pb.condition, "actions": pb.actions}})
        if route.startswith("/api/soar/playbook/") and route.endswith("/enable") and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            pid = route[len("/api/soar/playbook/"):-len("/enable")].strip("/")
            body = _read_body(self)
            enabled = bool((body or {}).get("enabled", True))
            store = getattr(eng, "soar_store", None)
            if store is None or not store.set_enabled(pid, enabled):
                return _send_json(self, {"ok": False, "error": "playbook no encontrado"}, 404)
            tdir = _tenants.data_dir(org)
            append_audit(tdir, {"event": "soar.playbook.enabled", "actor": user.get("id"), "playbook": pid, "enabled": enabled})
            reload_engine(org)
            return _send_json(self, {"ok": True, "playbook_id": pid, "enabled": enabled})
        if route.startswith("/api/soar/playbook/") and method == "DELETE":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            pid = route[len("/api/soar/playbook/"):].split("/")[0].strip("/")
            store = getattr(eng, "soar_store", None)
            if store is None or not store.delete(pid):
                return _send_json(self, {"ok": False, "error": "playbook no encontrado"}, 404)
            tdir = _tenants.data_dir(org)
            append_audit(tdir, {"event": "soar.playbook.deleted", "actor": user.get("id"), "playbook": pid})
            reload_engine(org)
            return _send_json(self, {"ok": True, "playbook_id": pid})

        # users

        # users
        if route == "/api/users" and method == "GET":
            if not AuthStore.can(user["org_roles"].get(org), "user:invite"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            members = [_auth.get(uid).to_public() for uid in
                        [u.id for u in _auth._users.values() if org in u.org_roles]]
            return _send_json(self, {"users": members})
        if route == "/api/users" and method == "POST":
            actor_role = user["org_roles"].get(org)
            if not AuthStore.can(actor_role, "user:invite"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self)
            requested_role = body.get("role", "viewer")
            if requested_role not in ROLE_CAPS:
                return _send_json(self, {"error": "rol inválido"}, 400)
            # Privilege-escalation guard: only an owner may grant owner/admin.
            # Admins (who hold user:invite) can create operator/viewer only.
            if requested_role in ("owner", "admin") and actor_role != "owner":
                return _send_json(self, {"error": "solo el propietario puede asignar owner/admin"}, 403)
            pw = body.get("password") or ""
            temp = False
            if not pw or pw == "TempPass123":
                pw = os.urandom(6).hex()  # contraseña temporal aleatoria (no hardcodeada)
                temp = True
            try:
                u = _auth.create_user(body["email"], body.get("name", body["email"]),
                                      pw, org, requested_role)
                out = {"ok": True, "user": u.to_public()}
                if temp:
                    out["temp_password"] = pw
                return _send_json(self, out)
            except (ValueError, KeyError) as e:
                return _send_json(self, {"error": str(e)}, 400)

        # members / RBAC surface (strictly tenant-local: only THIS org)
        if route == "/api/members" and method == "GET":
            if not AuthStore.can(user["org_roles"].get(org), "user:invite"):
                return _send_json(self, {"error": "sin permiso", "capability": "user:invite"}, 403)
            members = []
            for u in _auth.org_members(org):
                r = u.org_roles.get(org)
                members.append({
                    "id": u.id, "email": u.email, "name": u.name,
                    "role": r, "role_label": ROLE_LABELS.get(r, r),
                    "active": u.active, "created_at": u.created_at,
                    "is_self": u.id == user.get("id"),
                })
            members.sort(key=lambda m: (m["role"] != "owner", m["email"]))
            roles = [{"id": rid, "label": ROLE_LABELS.get(rid, rid),
                      "caps": sorted(ROLE_CAPS[rid])} for rid in ROLE_CAPS]
            return _send_json(self, {"members": members, "roles": roles,
                                     "self_id": user.get("id"),
                                     "owners": _auth.count_org_owners(org)})
        if route == "/api/members/role" and method == "POST":
            # Cambiar el rol de un miembro es sensible: exige la capability de
            # gestión de roles (user:role, solo owner). Un admin con user:invite
            # puede crear usuarios pero no reasignar roles existentes.
            if not AuthStore.can(user["org_roles"].get(org), "user:role") \
                    or user.get("auth_type") == "api_key":
                return _send_json(self, {"error": "solo un propietario con sesión puede gestionar roles",
                                         "capability": "user:role"}, 403)
            body = _read_body(self)
            new_role = (body.get("role") or "").strip()
            if new_role not in ROLE_CAPS:
                return _send_json(self, {"error": "rol inválido"}, 400)
            target_id = (body.get("user_id") or "").strip()
            target = _auth.get(target_id) if target_id else None
            if target is None:
                email = (body.get("email") or "").strip()
                target = _auth.get_by_email(email) if email else None
            if target is None or org not in target.org_roles:
                return _send_json(self, {"error": "el usuario no pertenece a la organización"}, 404)
            try:
                updated = _auth.set_org_role(target.id, org, new_role)
            except ValueError as e:
                return _send_json(self, {"error": str(e)}, 400)
            append_audit(_tenants.data_dir(org), {
                "event": "member.role.changed", "actor": user.get("id"),
                "target": updated.id, "target_email": updated.email, "role": new_role})
            return _send_json(self, {"ok": True, "member": {
                "id": updated.id, "email": updated.email, "name": updated.name,
                "role": new_role, "role_label": ROLE_LABELS.get(new_role, new_role)}})


        # settings / credentials (strictly tenant-local)
        if route == "/api/settings/status" and method == "GET":
            tdir = _tenants.data_dir(org)
            st = core_secrets.status(tdir)
            st["mode"] = eng.config.get("mode")
            st["dry_run"] = eng.config.get("dry_run")
            st["enforcement"] = eng.enforcement_status()
            st["masked_key"] = core_secrets.mask_key(tdir)
            runtime = _tenant_runtime(tdir)
            st["soar_webhook_hmac_configured"] = bool(runtime.get("soar_webhook_secret")
                                                      or os.environ.get("LUCIDFENCE_SOAR_WEBHOOK_SECRET"))
            st["soar_webhook_secret_masked"] = _masked_secret(runtime.get("soar_webhook_secret", ""))
            # Per-tenant outbound webhook egress policy (t_f33e2f23). Returned
            # for the dashboard wizard; default permissive when absent.
            _eg = runtime.get("egress_policy")
            if not isinstance(_eg, dict) or not _eg:
                st["egress_policy"] = {"mode": "permissive"}
            else:
                st["egress_policy"] = {
                    "mode": str(_eg.get("mode", "permissive")).lower(),
                    "allow": _eg.get("allow", []) if _eg.get("mode") == "strict" else [],
                    "allow_private": bool(_eg.get("allow_private", False)),
                }
            # Last outgoing-webhook delivery outcome (incl. egress denials) so
            # the dashboard can show `denied_by_egress_policy` explicitly.
            try:
                st["webhook_delivery"] = eng._webhook_delivery_status()
            except Exception:
                st["webhook_delivery"] = None
            return _send_json(self, st)
        if route == "/api/settings/enforcement" and method == "POST":
            # Editar la fase de enforcement (observe|enforce) desde el dashboard.
            # observe = todo dry-run; enforce = las live_actions salen en vivo.
            # Cambiar el modo no ejecuta ninguna acción por sí mismo.
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            new_mode = (_read_body(self).get("mode") or "").strip().lower()
            if new_mode not in ("observe", "enforce"):
                return _send_json(self, {"error": "modo inválido (observe|enforce)"}, 400)
            tdir = _tenants.data_dir(org)
            runtime = _tenant_runtime(tdir)
            runtime["enforcement_mode"] = new_mode
            tmp = tdir / "integration.json.tmp"
            tmp.write_text(json.dumps(runtime, indent=2), encoding="utf-8")
            os.chmod(tmp, 0o600)
            tmp.replace(tdir / "integration.json")
            os.chmod(tdir / "integration.json", 0o600)
            try:
                eng = reload_engine(org)
            except Exception as exc:
                return _send_json(self, {"ok": True, "mode": new_mode,
                                         "warning": f"guardado pero el engine no se recargó: {exc}"})
            append_audit(tdir, {"event": "enforcement.mode.changed",
                                "actor": user.get("id"), "mode": new_mode})
            return _send_json(self, {"ok": True, "enforcement": eng.enforcement_status()})
        # ---- Multi-UEM provider registry (tenant-local, isolated) ----------
        if route == "/api/providers/catalog" and method == "GET":
            from lucidfence.saas.providers import catalog
            return _send_json(self, {"catalog": catalog()})
        if route == "/api/providers/test" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self)
            name = (body.get("name") or "").strip().lower()
            from lucidfence.core.adapters import ADAPTER_REGISTRY
            if name not in ADAPTER_REGISTRY:
                return _send_json(self, {"ok": False, "error": "proveedor no soportado"}, 400)
            # Guard SSRF: un endpoint/base_url de proveedor debe ser un host
            # externo https, jamás loopback/privado/link-local (misma política
            # que el webhook de incidentes). Vacío = el adapter usa su default
            # empaquetado. Sin esto, el asistente de conector permitía escanear
            # infra interna y reflejar la respuesta del host interno al llamante.
            for _uf in ("endpoint", "base_url"):
                _u = (body.get(_uf) or "").strip()
                if _u and not _safe_webhook_url(_u):
                    return _send_json(self, {"ok": False, "error": "URL de proveedor no permitida (solo https, sin rangos privados/loopback/link-local)"}, 400)
            cls = ADAPTER_REGISTRY[name]
            # Build the adapter with every credential field the wizard sent.
            # Map "endpoint" -> endpoint_template; pass OAuth fields as-is.
            creds = {k: v for k, v in body.items()
                     if k not in ("name",) and isinstance(v, str)}
            creds.pop("endpoint", None)
            try:
                adapter = cls(
                    org_id=body.get("org_id", ""),
                    endpoint_template=body.get("endpoint", "") or "",
                    api_key=(body.get("api_key") or "").strip(),
                    **{k: v for k, v in creds.items()
                       if k in ("tenant_id", "client_id", "client_secret",
                                "refresh_token", "base_url", "username", "password",
                                "api_token", "tenant_code", "customer_id")},
                )
            except Exception as exc:
                return _send_json(self, {"ok": False, "error_type": "init",
                                         "error": f"no se pudo construir el conector: {exc}"}, 400)
            # SimulationAdapter (and others that ignore kwargs) still need the
            # key for test_connection's format check; set it explicitly.
            if not getattr(adapter, "api_key", None) and body.get("api_key"):
                try:
                    adapter.api_key = (body.get("api_key") or "").strip()
                except Exception:
                    pass
            result = adapter.test_connection()
            result["provider"] = name
            return _send_json(self, result)
        if route == "/api/providers" and method == "GET":
            tdir = _tenants.data_dir(org)
            return _send_json(self, {
                "providers": [_masked_provider(p) for p in _list_providers(tdir)],
                "health": _provider_health(eng),
            })
        if route == "/api/providers" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self)
            name = (body.get("name") or "").strip().lower()
            from lucidfence.core.adapters import ADAPTER_REGISTRY
            if name not in ADAPTER_REGISTRY:
                return _send_json(self, {"ok": False, "error": "proveedor no soportado"}, 400)
            # Guard SSRF (igual que /api/providers/test): un endpoint/base_url
            # persistido se usa en cada ciclo del engine; debe ser https externo.
            for _uf in ("endpoint", "base_url"):
                _u = (body.get(_uf) or "").strip()
                if _u and not _safe_webhook_url(_u):
                    return _send_json(self, {"ok": False, "error": "URL de proveedor no permitida (solo https, sin rangos privados/loopback/link-local)"}, 400)
            tdir = _tenants.data_dir(org)
            providers = _list_providers(tdir)
            providers = [p for p in providers
                         if not (p.get("name") == name and p.get("org_id") == body.get("org_id", ""))]
            # segment: etiqueta de flota (móviles/portátiles/…). No es secreto
            # y es lo que hace útil el multi-UEM: qué UEM cubre qué clase de
            # dispositivo (p.ej. Applivery=móviles + Fleet=portátiles).
            segment = (body.get("segment") or "").strip()[:40]
            # ponytail: secret stored in tenant-isolated integration.json (0600),
            # same trust boundary as core_secrets' .env; masked on GET.
            provider = {
                "name": name,
                "org_id": body.get("org_id", ""),
                "endpoint": (body.get("endpoint") or "").strip(),
                "secret": (body.get("api_key") or "").strip(),
            }
            if segment:
                provider["segment"] = segment
            # Scopes que el operador declara para este token (backlog §16). No
            # son secreto — son permisos, no credenciales — y sin ellos el
            # auditor de mínimo privilegio no tiene nada que auditar (y lo dice
            # así, en vez de dar el token por correcto).
            from lucidfence.core.least_privilege import normalize_declared_scopes
            declared_scopes = normalize_declared_scopes(body.get("scopes"))
            if declared_scopes:
                provider["scopes"] = declared_scopes
            # Persist any extra OAuth/connection fields (tenant_id, client_id,
            # client_secret, refresh_token) so the connector is functional.
            for extra in ("tenant_id", "client_id", "client_secret", "refresh_token",
                          "username", "password", "base_url",
                          "api_token", "tenant_code", "customer_id"):
                if body.get(extra):
                    provider[extra] = body[extra].strip()
            providers.append(provider)
            _save_providers(tdir, providers)
            # Rastro auditable: quién conectó qué UEM y para qué segmento. Nunca
            # el secreto (solo el nombre del proveedor y la etiqueta de flota).
            append_audit(tdir, {"event": "provider.registered",
                                "actor": user.get("id"), "provider": name,
                                "segment": segment})
            try:
                reload_engine(org)
            except Exception as exc:
                return _send_json(self, {"ok": True, "registered": name,
                                        "warning": f"engine reload falló: {exc}"}, 200)
            return _send_json(self, {"ok": True, "registered": name, "segment": segment})
        if route.startswith("/api/providers/") and method == "DELETE":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            name = route[len("/api/providers/"):].split("/")[0]
            tdir = _tenants.data_dir(org)
            providers = [p for p in _list_providers(tdir)
                         if not (p.get("name") == name)]
            _save_providers(tdir, providers)
            append_audit(tdir, {"event": "provider.removed",
                                "actor": user.get("id"), "provider": name})
            try:
                reload_engine(org)
            except Exception:
                pass
            return _send_json(self, {"ok": True, "removed": name})
        if route == "/api/settings" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self)
            tdir = _tenants.data_dir(org)
            requested_key = body.get("api_key")
            if not (requested_key or "").strip() and core_secrets.read_key(tdir):
                requested_key = None
            res = core_secrets.save_credentials(tdir, requested_key, body.get("org_id"))
            if not res.get("ok"):
                return _send_json(self, {"ok": False, "error": res.get("error")}, 400)
            new_mode = body.get("mode") or ("live" if res.get("configured") else "simulation")
            if new_mode not in ("live", "simulation"):
                return _send_json(self, {"ok": False, "error": "modo inválido"}, 400)
            dry_run = bool(body.get("dry_run", eng.config.get("dry_run", True)))
            current_runtime = {}
            try:
                current_runtime = json.loads((tdir / "integration.json").read_text(encoding="utf-8"))
            except Exception:
                current_runtime = {}
            _save_tenant_integration(
                tdir, new_mode, dry_run,
                incident_webhook_url=current_runtime.get("incident_webhook_url", ""),
            )
            try:
                eng = reload_engine(org)
            except Exception as exc:
                return _send_json(self, {"ok": True, "mode": new_mode, "dry_run": dry_run,
                                        "configured": res.get("configured"),
                                        "warning": f"credenciales guardadas pero el engine no se recargó: {type(exc).__name__}: {exc}"})
            return _send_json(self, {"ok": True, "mode": eng.config.get("mode"),
                                     "dry_run": eng.config.get("dry_run"),
                                     "configured": res.get("configured")})
        if route == "/api/settings/test" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self)
            tdir = _tenants.data_dir(org)
            key = (body.get("api_key") or "").strip() or core_secrets.read_key(tdir)
            if not key:
                return _send_json(self, {"ok": False, "error": "no hay token"}, 400)
            return _send_json(self, core_secrets.test_applivery_token(key))
        if route == "/api/settings/incident-webhook" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self)
            url = (body.get("url") or "").strip()
            # SSRF guard: only https, and never internal/link-local targets.
            url = _safe_webhook_url(url)
            if (body.get("url") or "").strip() and not url:
                return _send_json(self, {"ok": False, "error": "URL no permitida (solo https, sin rangos privados)"}, 400)
            # Per-tenant egress policy (t_f33e2f23): validate before persisting.
            ok_eg, err_eg, policy_eg = _validate_egress_policy(body.get("egress_policy"))
            if not ok_eg:
                return _send_json(self, {"ok": False, "error": f"egress_policy inválido: {err_eg}"}, 400)
            tdir = _tenants.data_dir(org)
            _save_tenant_integration(tdir, eng.config.get("mode", "simulation"),
                                     eng.config.get("dry_run", True),
                                     incident_webhook_url=url,
                                     egress_policy=policy_eg)
            # rebuild engine so the notifier picks up the new webhook + policy
            try:
                reload_engine(org)
            except Exception:
                pass
            return _send_json(self, {"ok": True, "configured": bool(url),
                                     "egress_policy": policy_eg})
        if route == "/api/settings/soar-webhook-secret" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self)
            secret = (body.get("secret") or "").strip()
            if secret and len(secret) < 16:
                return _send_json(self, {"ok": False, "error": "secret demasiado corto (mínimo 16 caracteres)"}, 400)
            tdir = _tenants.data_dir(org)
            runtime = _tenant_runtime(tdir)
            if secret:
                runtime["soar_webhook_secret"] = secret
            else:
                runtime.pop("soar_webhook_secret", None)
            tmp = tdir / "integration.json.tmp"
            tmp.write_text(json.dumps(runtime, indent=2), encoding="utf-8")
            os.chmod(tmp, 0o600)
            tmp.replace(tdir / "integration.json")
            os.chmod(tdir / "integration.json", 0o600)
            return _send_json(self, {"ok": True,
                                     "configured": bool(secret),
                                     "webhook_path": f"/api/soar/webhook/{org}",
                                     "signature": "HMAC-SHA256 over '<timestamp>.<raw_body>'"})

        # ---- Configurable threshold alerts (MDM/UEM alerting) -----------
        if route == "/api/alerts" and method == "GET":
            return _send_json(self, {
                "rules": eng.alerts.list_rules(),
                "firings": eng.alerts.recent_firings(100),
                "types": sorted(ALERT_TYPES),
                "labels": ALERT_TYPE_LABELS,
                "channels": sorted(CHANNELS),
            })
        if route == "/api/alerts" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self)
            try:
                rule = eng.alerts.add_rule(body)
            except (ValueError, KeyError) as exc:
                return _send_json(self, {"error": f"regla invalida: {exc}"}, 400)
            return _send_json(self, {"ok": True, "rule": rule.to_dict()})
        if route.startswith("/api/alerts/") and route.endswith("/delete") and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            rid = route[len("/api/alerts/"):-len("/delete")]
            ok = eng.alerts.delete_rule(rid)
            return _send_json(self, {"ok": ok})
        if route == "/api/alerts/evaluate" and method == "POST":
            # on-demand evaluation of all rules against the live snapshot
            devs = [s.to_dict() for s in eng.store.snapshot().values()]
            fired = eng.alerts.evaluate(devs)
            return _send_json(self, {"ok": True, "firings": fired, "count": len(fired)})

        if route == "/api/atomicmail/status" and method == "GET":
            tdir = _tenants.data_dir(org)
            runtime = {}
            try:
                runtime = json.loads((tdir / "integration.json").read_text(encoding="utf-8"))
            except Exception:
                runtime = {}
            am = runtime.get("atomicmail") or {}
            # Never leak the api_key; only report configured + masked inbox.
            configured = bool(am.get("username") or am.get("api_key"))
            masked_key = ("*" * 8 + (am["api_key"][-4:] if am.get("api_key") else "")) if am.get("api_key") else ""
            out = {
                "configured": configured,
                "username": am.get("username", ""),
                "masked_api_key": masked_key,
                "incident_email_to": am.get("incident_email_to", ""),
                "digest_email_to": am.get("digest_email_to", ""),
                "ready": False,
                "inbox": None,
                "last_error": None,
            }
            mb = eng.mailbox
            if mb is not None:
                st = mb.status()
                out["ready"] = st.get("ready")
                out["inbox"] = st.get("inbox")
                out["last_error"] = st.get("last_error")
            return _send_json(self, out)
        if route == "/api/atomicmail/setup" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self)
            tdir = _tenants.data_dir(org)
            am_cfg = {
                "username": (body.get("username") or "").strip(),
                "api_key": (body.get("api_key") or "").strip(),
                "incident_email_to": (body.get("incident_email_to") or "").strip(),
                "digest_email_to": (body.get("digest_email_to") or "").strip(),
            }
            if not (am_cfg["username"] or am_cfg["api_key"]):
                return _send_json(self, {"ok": False, "error": "requiere username o api_key"}, 400)
            _save_tenant_integration(
                tdir, eng.config.get("mode", "simulation"),
                eng.config.get("dry_run", True),
                incident_webhook_url=eng.config.get("incident_webhook_url", ""),
                atomicmail=am_cfg,
            )
            try:
                reload_engine(org)
            except Exception as exc:
                return _send_json(self, {"ok": True, "warning": f"config guardada pero engine no recargó: {exc}"})
            return _send_json(self, {"ok": True,
                                     "configured": bool(eng.mailbox is not None),
                                     "inbox": eng.mailbox.status().get("inbox") if eng.mailbox else None})
        if route == "/api/atomicmail/test" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self)
            to = (body.get("to") or "").strip()
            mb = eng.mailbox
            if mb is None:
                return _send_json(self, {"ok": False, "error": "atomicmail no configurado"}, 400)
            if not to:
                return _send_json(self, {"ok": False, "error": "falta 'to'"}, 400)
            try:
                ok = mb.send(to=to, subject="[LucidFence] Test de Atomic Mail",
                             text="Este es un correo de prueba enviado por LucidFence vía Atomic Mail Agentic.")
                return _send_json(self, {"ok": ok, "inbox": mb._inbox_id,
                                         "last_error": mb.last_error})
            except Exception as exc:
                return _send_json(self, {"ok": False, "error": f"{type(exc).__name__}: {exc}"})
        if route == "/api/atomicmail/digest" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self) or {}
            to = (body.get("to") or "").strip() or None
            ok = eng.send_digest(to=to)
            return _send_json(self, {"ok": ok})

        # ---- Whitelabel (DigitalPlat FreeDomain) -------------------------
        if route == "/api/whitelabel/suggest" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self) or {}
            domain = (body.get("domain") or "").strip()
            if not domain:
                return _send_json(self, {"ok": False, "error": "requiere domain"}, 400)
            from lucidfence.core.freedomain import suggest_dns_records
            try:
                sug = suggest_dns_records(
                    domain,
                    atomicmail_inbox=(eng.mailbox._inbox_id if eng.mailbox else "") or "",
                    dkim_selector=(body.get("dkim_selector") or "atomicmail"),
                    dashboard_target=(body.get("dashboard_target") or "").strip(),
                    receive_mail=bool(body.get("receive_mail", True)),
                )
                return _send_json(self, {"ok": True, "suggestion": sug})
            except ValueError as exc:
                return _send_json(self, {"ok": False, "error": str(exc)}, 400)
        if route == "/api/whitelabel/setup" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self)
            domain = (body.get("domain") or "").strip()
            if not domain:
                return _send_json(self, {"ok": False, "error": "requiere domain"}, 400)
            tdir = _tenants.data_dir(org)
            wl_cfg = {
                "domain": domain,
                "dkim_selector": (body.get("dkim_selector") or "atomicmail").strip(),
                "dashboard_target": (body.get("dashboard_target") or "").strip(),
            }
            _save_tenant_integration(
                tdir, eng.config.get("mode", "simulation"),
                eng.config.get("dry_run", True),
                incident_webhook_url=eng.config.get("incident_webhook_url", ""),
                atomicmail=eng.config.get("atomicmail"),
                whitelabel=wl_cfg,
            )
            try:
                reload_engine(org)
            except Exception as exc:
                return _send_json(self, {"ok": True, "warning": f"config guardada pero engine no recargó: {exc}"})
            return _send_json(self, {"ok": True, "domain": domain,
                                     "sender": f"{eng.config.get('atomicmail', {}).get('username', '')}@{domain}"})
        if route == "/api/whitelabel/status" and method == "GET":
            tdir = _tenants.data_dir(org)
            runtime = {}
            try:
                runtime = json.loads((tdir / "integration.json").read_text(encoding="utf-8"))
            except Exception:
                runtime = {}
            wl = runtime.get("whitelabel") or {}
            out = {
                "configured": bool(wl.get("domain")),
                "domain": wl.get("domain", ""),
                "dkim_selector": wl.get("dkim_selector", "atomicmail"),
                "dashboard_target": wl.get("dashboard_target", ""),
                "last_validation": wl.get("last_validation"),
                "sender": (
                    f"{eng.config.get('atomicmail', {}).get('username', '')}@{wl['domain']}"
                    if wl.get("domain") else None
                ),
            }
            return _send_json(self, out)
        if route == "/api/whitelabel/validate" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self) or {}
            tdir = _tenants.data_dir(org)
            runtime = {}
            try:
                runtime = json.loads((tdir / "integration.json").read_text(encoding="utf-8"))
            except Exception:
                runtime = {}
            domain = (body.get("domain") or runtime.get("whitelabel", {}).get("domain") or "").strip()
            if not domain:
                return _send_json(self, {"ok": False, "error": "sin dominio configurado"}, 400)
            from lucidfence.core.freedomain import validate
            report = validate(domain, dkim_selector=(runtime.get("whitelabel", {}).get("dkim_selector") or "atomicmail"))
            # Persist last validation in the whitelabel config (non-secret).
            wl = runtime.get("whitelabel") or {}
            wl["last_validation"] = report
            runtime["whitelabel"] = wl
            try:
                tmp = tdir / "integration.json.tmp"
                tmp.write_text(json.dumps(runtime, indent=2), encoding="utf-8")
                os.chmod(tmp, 0o600)
                tmp.replace(tdir / "integration.json")
                os.chmod(tdir / "integration.json", 0o600)
            except Exception:
                pass
            return _send_json(self, {"ok": True, "report": report})

        # ---- Bulk export / audit (CSV + print-ready HTML) ----------------
        if route == "/api/export" and method == "GET":
            if not AuthStore.can(user["org_roles"].get(org), "report:export"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            kind = (qs.get("kind", ["inventory"])[0]).lower()
            fmt = (qs.get("format", ["csv"])[0]).lower()
            from lucidfence.core import export as EXP
            if kind == "actions":
                actions = eng.store.recent_actions(5000)
                if fmt == "html":
                    return _send_html(self, EXP.export_inventory_html([], org,
                        {"total": len(actions)}))
                return _send_csv(self, "acciones_uem.csv", EXP.export_actions_csv(actions))
            if kind == "compliance":
                devs = [s.to_dict() for s in eng.store.snapshot().values()]
                if fmt == "pdf":
                    return _send_pdf(self, "reporte_conformidad.pdf",
                                     EXP.export_compliance_pdf(devs, org, _summary(devs)))
                if fmt == "html":
                    return _send_html(self, EXP.export_inventory_html(devs, org,
                        _summary(devs)))
                return _send_csv(self, "compliance.csv", EXP.export_compliance_csv(devs))
            # default: inventory
            devs = [s.to_dict() for s in eng.store.snapshot().values()]
            if fmt == "html":
                return _send_html(self, EXP.export_inventory_html(devs, org, _summary(devs)))
            return _send_csv(self, "inventario_uem.csv", EXP.export_inventory_csv(devs))

        # ---- Optional BYO AI provider (tenant-local, OpenAI-compatible) ----
        if route in ("/api/ai/providers", "/api/ai/settings") and method == "GET":
            ai_status = ai_provider.status(_tenants.data_dir(org))
            if route == "/api/ai/providers":
                provider_row = []
                if ai_status.get("configured"):
                    provider_row = [{"name": ai_status.get("provider"), "model": ai_status.get("model"), "available": True}]
                return _send_json(self, {"online": ai_status.get("configured", False),
                                         "providers": provider_row, "status": ai_status})
            return _send_json(self, ai_status)
        if route == "/api/ai/settings" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            result = ai_provider.save(_tenants.data_dir(org), _read_body(self))
            return _send_json(self, result, 200 if result.get("ok") else 400)
        if route == "/api/ai/test" and method == "POST":
            if not AuthStore.can(user["org_roles"].get(org), "engine:config"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            body = _read_body(self)
            # Test unsaved fields in a secure temporary directory; never mutate
            # tenant configuration until the operator presses Save.
            if any(k in body for k in ("base_url", "model", "api_key")):
                result = ai_provider.test_values(body)
            else:
                result = ai_provider.test_connection(_tenants.data_dir(org))
            return _send_json(self, result, 200 if result.get("ok") else 502)
        if route in ("/api/ai", "/api/ai/chat") and method == "POST":
            body = _read_body(self)
            messages = body.get("messages") if isinstance(body, dict) else None
            if not isinstance(messages, list) or not messages:
                return _send_json(self, {"ok": False, "error": "messages debe ser una lista no vacía"}, 400)
            result = ai_provider.chat(_tenants.data_dir(org), messages, body)
            if not result.get("ok"):
                return _send_json(self, result, int(result.get("status") or 502))
            cfg = ai_provider.status(_tenants.data_dir(org))
            return _send_json(self, {"ok": True, "text": result.get("text"),
                                     "provider": cfg.get("provider"), "model": cfg.get("model"),
                                     "response": result.get("response")})

        # ---- IA: borrador de respuesta de soporte (todo impulsado por IA) --
        if route == "/api/ai/support" and method == "POST":
            body = _read_body(self) or {}
            ticket = {
                "subject": (body.get("subject") or body.get("topic") or "").strip(),
                "body": (body.get("body") or body.get("message") or "").strip(),
            }
            if not ticket["subject"] and not ticket["body"]:
                return _send_json(self, {"ok": False, "error": "requiere subject/body"}, 400)
            try:
                from lucidfence.core import ai
                reply = ai.support_reply(ticket, dry=True)
            except Exception as exc:
                return _send_json(self, {"ok": False,
                    "error": f"motor IA no disponible: {exc}"}, 503)
            return _send_json(self, {
                "ok": True,
                "reply": reply,
                "moa_available": ai.available(),
            })

        self.send_error(404)

    # ---- auth handlers --------------------------------------------------
    def _oidc_start(self, provider_name: str, qs: dict):
        try:
            if set(qs) - {"return_path"} or len(qs.get("return_path", ["/app"])) != 1:
                raise OIDCError("invalid_return_path")
            browser = _cookie(self, COOKIE_OIDC_PREAUTH) or os.urandom(32).hex()
            started = _oidc_client.start(provider_name, browser, qs.get("return_path", ["/app"])[0], "login")
            _set_oidc_cookie(self, COOKIE_OIDC_PREAUTH, browser, 600)
            return _send_redirect(self, started.authorization_url, 302)
        except OIDCError as exc:
            status = 503 if exc.code == "provider_unavailable" else 400
            return _send_json(self, {"error": exc.code}, status)

    def _oidc_callback(self, provider_name: str, raw_query: str):
        browser = _cookie(self, COOKIE_OIDC_PREAUTH) or ""
        return_path = _oidc_client.callback_return_path(provider_name, raw_query, browser)
        try:
            result = _oidc_client.callback(provider_name, raw_query, browser)
            if result.purpose != "login":
                raise OIDCError("unsupported_flow_purpose")
            claims = result.claims
            provider = _oidc_providers[result.provider]
            issuer, subject = str(claims.get("iss") or ""), str(claims.get("sub") or "")
            existing = _auth.get_by_external_identity(issuer, subject)
            email = str(claims.get("email") or "").strip().lower()
            if existing is None:
                domain = email.rsplit("@", 1)[-1] if "@" in email else ""
                if claims.get("email_verified") is not True or domain not in provider.allowed_domains:
                    raise OIDCError("provisioning_denied")
                if not provider.provision_org_id or provider.provision_role == "owner":
                    raise OIDCError("provisioning_denied")
            old_session = _cookie(self, COOKIE_SESSION) or ""
            org_id = provider.provision_org_id
            role = provider.provision_role
            if existing and existing.org_roles:
                org_id, role = next(iter(existing.org_roles.items()))
            user, token = _auth.complete_oidc_login(issuer, subject, email,
                                                    str(claims.get("name") or email),
                                                    org_id, role, old_session=old_session)
            _clear_cookie(self, COOKIE_OIDC_PREAUTH)
            _set_oidc_cookie(self, COOKIE_SESSION, token, _auth.session_ttl)
            _set_oidc_cookie(self, COOKIE_ORG, org_id, _auth.session_ttl)
            _log_event("oidc_login", provider=result.provider, outcome="success", user_id=user.id)
            return _send_redirect(self, result.return_path, 303, no_referrer=True)
        except OIDCError as exc:
            _clear_cookie(self, COOKIE_OIDC_PREAUTH)
            _log_event("oidc_login", provider=provider_name, outcome="failure", reason=exc.code)
            return _send_redirect(self, return_path + "?auth_error=sso_failed", 303, no_referrer=True)
        except ValueError as exc:
            _clear_cookie(self, COOKIE_OIDC_PREAUTH)
            _log_event("oidc_login", provider=provider_name, outcome="failure", reason=str(exc))
            return _send_redirect(self, return_path + "?auth_error=sso_failed", 303, no_referrer=True)

    def _signup(self):
        body = _read_body(self)
        email = (body.get("email") or "").strip()
        name = (body.get("name") or "").strip()
        password = body.get("password") or ""
        org_name = (body.get("org_name") or "").strip()
        if not email or not password or not org_name:
            return _send_json(self, {"error": "email, password y org_name son obligatorios"}, 400)
        if len(password) < 8:
            return _send_json(self, {"error": "la contraseña debe tener >= 8 caracteres"}, 400)
        if _auth.get_by_email(email):
            return _send_json(self, {"error": "el email ya está registrado"}, 400)
        # Signup ONLY creates a brand-new organisation (owner). Joining an
        # existing org by guessing its name is forbidden — membership in an
        # existing tenant must go through an authenticated invite
        # (POST /api/users), never through public signup. This closes the
        # "self-add as viewer to any org" escalation.
        from lucidfence.saas.tenant import slugify
        if _tenants.get_by_slug(slugify(org_name)):
            return _send_json(self, {"error": "el nombre de organización ya existe; pide una invitación al propietario"}, 409)
        org = _tenants.create(org_name, owner_id="")
        role = "owner"
        user = _auth.create_user(email, name or email, password, org.id, role)
        org.owner_id = user.id
        _tenants._save()

        token = _auth.create_session(user.id)
        _set_cookie(self, COOKIE_SESSION, token)
        _set_cookie(self, COOKIE_ORG, org.id)
        welcome_email = _send_signup_welcome_email(email, name or email, org)
        _send_json(self, {"ok": True, "token": token, "user": user.to_public(),
                          "org": org.to_dict(), "plan": FREE_PLAN,
                          "welcome_email": welcome_email})

    def _login(self):
        body = _read_body(self)
        user = _auth.authenticate(body.get("email", ""), body.get("password", ""))
        if not user:
            return _send_json(self, {"error": "credenciales inválidas"}, 401)
        token = _auth.create_session(user.id)
        _set_cookie(self, COOKIE_SESSION, token)
        first_org = next(iter(user.org_roles), None)
        if first_org:
            _set_cookie(self, COOKIE_ORG, first_org)
        _send_json(self, {"ok": True, "token": token, "user": user.to_public(),
                          "orgs": [o.to_dict() for o in _tenants.list_for_user(user.id)]})

    def _demo_login(self):
        """One-click onboarding, available only on a loopback-bound app."""
        bound_host = _bound_host(self)
        loopback_hosts = {"127.0.0.1", "localhost", "::1"}
        client_host = (self.client_address[0] if self.client_address else "").lower()
        if (bound_host not in loopback_hosts or client_host not in loopback_hosts):
            if os.environ.get("LUCIDFENCE_ALLOW_REMOTE_DEMO_LOGIN") != "1":
                return _send_json(self, {"error": "demo login solo disponible en loopback"}, 403)

        email = "ciso@acme.test"
        user = _auth.get_by_email(email)
        if user is None:
            demo_org = None
            for org in _tenants.all():
                if org.slug == "acme-logistics":
                    demo_org = org
                    break
            if demo_org is None:
                demo_org = _tenants.create("Acme Logistics (demo)", "usr_demo_seed")
            user = _auth.create_user(email, "CISO Acme (demo)", "demo1234", demo_org.id, "owner")
            demo_org.owner_id = user.id
            _tenants._save()
        else:
            first_org = next(iter(user.org_roles), None)
            current_org = _tenants.get(first_org) if first_org else None
            if current_org is None:
                demo_org = _tenants.create("Acme Logistics (demo)", user.id)
                _auth.add_org_role(user.id, demo_org.id, "owner")
                user = _auth.get(user.id) or user
            elif current_org.owner_id != user.id:
                current_org.owner_id = user.id
                _tenants._save()
        token = _auth.create_session(user.id)
        _set_cookie(self, COOKIE_SESSION, token)
        first_org = next(iter(user.org_roles), None)
        if first_org:
            _set_cookie(self, COOKIE_ORG, first_org)
        return _send_json(self, {"ok": True, "token": token, "user": user.to_public(),
                                 "orgs": [o.to_dict() for o in _tenants.list_for_user(user.id)],
                                 "message": "demo local lista"})

    def _logout(self):
        token = _cookie(self, COOKIE_SESSION)
        if token:
            _auth.destroy_session(token)
        _clear_cookie(self, COOKIE_SESSION)
        _clear_cookie(self, COOKIE_ORG)
        _send_json(self, {"ok": True})

    # ---- product intelligence ------------------------------------------
    def _product(self, route: str, eng: Engine, user: dict, org: str, method: str, qs: dict):
        product = _product_bundle(eng)
        if route == "/api/incidents":
            return _send_json(self, {"incidents": product.get("incidents", []),
                                     "summary": product.get("summary", {})})

        if route == "/api/incidents/export" and method == "GET":
            if not AuthStore.can(user["org_roles"].get(org), "incident:read"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            fmt = (qs.get("format", ["csv"])[0] or "csv").lower()
            rows = eng.incidents.list()
            if fmt == "csv":
                from lucidfence.core.incidents import to_csv
                csv_text = to_csv(rows)
                payload = csv_text.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/csv; charset=utf-8")
                self.send_header("Content-Disposition",
                                 "attachment; filename=\"incidents.csv\"")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)
                return
            return _send_json(self, {"incidents": rows, "summary": product.get("summary", {})})
        if route == "/api/soar" and method == "GET":
            if not AuthStore.can(user["org_roles"].get(org), "device:read"):
                return _send_json(self, {"error": "sin permiso"}, 403)
            from lucidfence.core.soar import DEFAULT_PLAYBOOKS, evaluate_soar
            from lucidfence.core.adapters.capabilities import capability_for
            from lucidfence.core.adapters import ADAPTER_REGISTRY
            devs = list(eng.store.snapshot().values())
            # Evalúa builtin + tenant (REQ §5) para el "matched" en vivo.
            playbooks = eng.soar_store.all_playbooks() if getattr(eng, "soar_store", None) else DEFAULT_PLAYBOOKS
            soar_ctx = {"cycle": getattr(eng, "cycle_count", 0), "on_error": None}
            recent = []
            for d in devs:
                try:
                    execs = evaluate_soar(d.to_dict(), playbooks, soar_ctx)
                except Exception:
                    execs = []
                for ex in execs:
                    recent.append({
                        "playbook_id": ex.get("playbook_id"),
                        "name": ex.get("name"),
                        "device_id": d.device_id,
                        "device_name": d.name,
                        "severity": ex.get("severity"),
                        "actions": ex.get("actions"),
                    })
            # Matriz de capacidades por UEM (diseño §3.1 / REQ §3): la UI ofrece
            # solo lo que el UEM soporta y marca las acciones en dry-run pendientes
            # de validar (decisión §10.2).
            capability_matrix = {}
            for name in ADAPTER_REGISTRY:
                cap = capability_for(name)
                if cap is not None:
                    capability_matrix[name] = {
                        "inventory": cap.inventory,
                        "location": cap.location,
                        "native_geofences": cap.native_geofences,
                        "actions": sorted(cap.actions),
                        "dry_run_actions": sorted(cap.dry_run_actions),
                    }
            tenant_pbs = []
            errors = []
            if getattr(eng, "soar_store", None) is not None:
                tenant_pbs = [{
                    "id": pb.id, "name": pb.name, "description": pb.description,
                    "enabled": pb.enabled, "severity_min": pb.severity_min,
                    "condition": pb.condition, "actions": pb.actions,
                } for pb in eng.soar_store.load()]
                errors = eng.soar_store.errors()
            return _send_json(self, {
                "playbooks": [{
                    "id": pb.id, "name": pb.name, "description": pb.description,
                    "enabled": pb.enabled, "severity_min": pb.severity_min,
                    "actions": pb.actions, "builtin": True,
                } for pb in DEFAULT_PLAYBOOKS],
                "tenant_playbooks": tenant_pbs,
                "tenant_playbook_errors": errors,
                "capability_matrix": capability_matrix,
                "matched": recent,
                "devices_scanned": len(devs),
            })
        if route == "/api/policies":
            return _send_json(self, {"policies": product.get("policies", [])})
        if route == "/api/analytics":
            return _send_json(self, {"analytics": product.get("analytics", {}),
                                     "summary": product.get("summary", {})})
        if route == "/api/compliance":
            a = product.get("analytics", {})
            devs = list(eng.store.snapshot().values())
            non = sum(1 for s in devs if s.compliant is False)
            total = len(devs)
            return _send_json(self, {
                "compliance_percent": round((total - non) / total * 100) if total else 0,
                "series": a.get("compliance_series", []),
                "state_distribution": a.get("state_distribution", {}),
                "controls": map_controls(
                    [item.to_dict() if hasattr(item, "to_dict") else dict(vars(item)) for item in devs],
                    product.get("cve_summary", {}),
                    verify_audit(_tenants.data_dir(org)),
                ),
                "framework_disclaimer": "Evidence mapping only; not CIS/ISO certification.",
            })
        if route == "/api/report":
            return _send_json(self, {"report": product.get("report", {})})
        if route == "/api/activation":
            return _send_json(self, {"activation": product.get("activation", {})})
        self.send_error(404)


def _start_parent_watchdog() -> None:
    """Exit a desktop backend if its launcher disappears abnormally."""
    raw = os.environ.get("LUCIDFENCE_PARENT_PID", "").strip()
    if not raw:
        return
    try:
        parent_pid = int(raw)
    except ValueError:
        raise RuntimeError("LUCIDFENCE_PARENT_PID must be numeric")
    if parent_pid <= 1:
        raise RuntimeError("LUCIDFENCE_PARENT_PID must identify a user process")

    def watch() -> None:
        while True:
            time.sleep(0.5)
            if os.getppid() != parent_pid:
                os._exit(0)
            try:
                os.kill(parent_pid, 0)
            except ProcessLookupError:
                os._exit(0)
            except PermissionError:
                os._exit(0)

    threading.Thread(target=watch, name="desktop-parent-watchdog", daemon=True).start()


def main():
    _start_parent_watchdog()
    if any(provider.enabled for provider in _oidc_providers.values()):
        workers = int(os.environ.get("LUCIDFENCE_WORKERS", "1") or "1")
        if workers != 1:
            raise RuntimeError("OIDC JSON flow/session storage requires LUCIDFENCE_WORKERS=1")
    cfg = config_loader.load(CONFIG_FILE)
    global _SIMULATION, _cluster_lease
    _SIMULATION = (cfg.get("mode") == "simulation")
    host = os.environ.get("LUCIDFENCE_HOST") or cfg.get("server", {}).get("host", "127.0.0.1")
    port = int(os.environ.get("LUCIDFENCE_PORT") or cfg.get("server", {}).get("port", 8765))
    _validate_oidc_startup(_oidc_providers, host, port)
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] LucidFence local app running at http://{host}:{port}")
    print(f"  mode={cfg.get('mode')} dry_run={cfg.get('dry_run')}")
    print(f"  data={DATA_ROOT}")
    if os.environ.get("LUCIDFENCE_CLUSTER_MODE") == "active-passive":
        _cluster_lease = ClusterLease(DATA_ROOT, os.environ.get("LUCIDFENCE_NODE_ID"))
        if not _cluster_lease.acquire():
            raise RuntimeError("standby: another LucidFence node holds the writer lease")
        print(f"  cluster=active-passive leader={_cluster_lease.node_id}")
    httpd = LucidFenceHTTPServer((host, port), Handler)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print(f"[{ts}] Shutdown requested.")
        httpd.shutdown()
    finally:
        if _cluster_lease:
            _cluster_lease.release()


if __name__ == "__main__":
    main()